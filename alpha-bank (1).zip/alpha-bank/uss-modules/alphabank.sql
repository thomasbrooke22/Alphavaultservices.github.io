-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 15, 2023 at 03:47 PM
-- Server version: 10.5.20-MariaDB-cll-lve-log
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `scrixuez_alphabank`
--

-- --------------------------------------------------------

--
-- Table structure for table `uss_beneficiaries`
--

CREATE TABLE `uss_beneficiaries` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `bank_account` varchar(20) NOT NULL,
  `bank_region` varchar(100) NOT NULL,
  `bank_info` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `uss_beneficiaries`
--

INSERT INTO `uss_beneficiaries` (`id`, `userid`, `bank_account`, `bank_region`, `bank_info`) VALUES
(1, 1, '7878887666', 'international', '{\"bank_name\":\"Zenith Bank\",\"bank_holder\":\"Unknown User\",\"bank_country\":\"BS\"}'),
(2, 3, '234567890874', 'international', '{\"bank_name\":\"Trial Bank\",\"bank_holder\":\"Sam Ken\",\"bank_country\":\"MT\"}'),
(3, 3, '7654325678', 'local', '{\"bank_name\":\"UBA\",\"bank_holder\":\"Stephen\",\"bank_country\":null,\"identifier\":null,\"identifier_code\":null}'),
(4, 3, '234567994', 'local', '{\"bank_name\":\"UBA Advance\",\"bank_holder\":\"wegreh ken\",\"bank_country\":null,\"identifier\":null,\"identifier_code\":null}'),
(5, 3, '87654326453', 'local', '{\"bank_name\":\"FCMB\",\"bank_holder\":\"bola dima\",\"bank_country\":null,\"identifier\":null,\"identifier_code\":null}'),
(6, 3, '09876543', 'international', '{\"bank_name\":\"Access Bank\",\"bank_holder\":\"King Pin\",\"bank_country\":\"GA\",\"identifier\":\"Routing Number / Bank Code\",\"identifier_code\":\"4657687\"}');

-- --------------------------------------------------------

--
-- Table structure for table `uss_cards`
--

CREATE TABLE `uss_cards` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `card_type` varchar(10) NOT NULL DEFAULT 'debit',
  `vendor` varchar(20) NOT NULL DEFAULT 'mastercard',
  `cvv` varchar(3) NOT NULL,
  `card_number` varchar(16) NOT NULL,
  `expiry` varchar(6) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'pending',
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `uss_cards`
--

INSERT INTO `uss_cards` (`id`, `userid`, `card_type`, `vendor`, `cvv`, `card_number`, `expiry`, `status`, `date`) VALUES
(1, 6, 'credit', 'mastercard', '871', '5322747072704381', '08/26', 'pending', '2023-08-06 09:54:28'),
(2, 3, 'debit', 'visacard', '609', '4441705340918251', '08/26', 'pending', '2023-08-10 11:39:39'),
(3, 15, 'credit', 'mastercard', '920', '5370615099610037', '08/26', 'active', '2023-08-14 10:33:10');

-- --------------------------------------------------------

--
-- Table structure for table `uss_cheques`
--

CREATE TABLE `uss_cheques` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `amount` float DEFAULT 0,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(20) NOT NULL DEFAULT 'pending'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `uss_deposits`
--

CREATE TABLE `uss_deposits` (
  `id` int(11) NOT NULL,
  `tx_ref` varchar(40) NOT NULL,
  `userid` int(11) NOT NULL,
  `usd_amount` float DEFAULT NULL,
  `network` varchar(255) DEFAULT NULL,
  `rate` float DEFAULT 0,
  `detail` text DEFAULT NULL,
  `txid` varchar(255) DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `paid` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `uss_deposits`
--

INSERT INTO `uss_deposits` (`id`, `tx_ref`, `userid`, `usd_amount`, `network`, `rate`, `detail`, `txid`, `status`, `date`, `paid`) VALUES
(1, 'TNX64da0282a8e65', 15, 25000, 'BTC', 0, '{\"bitcoin_wallet\":\"bc1q8r2n40q3h57vl7hfl50exqaa6gnjgf9g428pgg\",\"medium\":\"crypto\"}', 'rtyui87656543', 'approved', '2023-08-14 10:31:30', 1);

-- --------------------------------------------------------

--
-- Table structure for table `uss_exchanges`
--

CREATE TABLE `uss_exchanges` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `paid_amount` float DEFAULT NULL COMMENT 'user paid',
  `paid_currency` varchar(4) DEFAULT NULL COMMENT 'user paid',
  `usd_value` float DEFAULT NULL COMMENT 'USD equivalance',
  `usd_fee` float DEFAULT NULL COMMENT 'cost in USD',
  `expected_amount` float DEFAULT NULL COMMENT 'user will receive',
  `expected_currency` varchar(4) DEFAULT NULL COMMENT 'user will receiver',
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `funded` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `uss_exchanges`
--

INSERT INTO `uss_exchanges` (`id`, `userid`, `paid_amount`, `paid_currency`, `usd_value`, `usd_fee`, `expected_amount`, `expected_currency`, `date`, `status`, `funded`) VALUES
(1, 3, 4, 'USD', 4, 0, 3000, 'NGN', '2023-07-31 23:49:41', 'approved', 1),
(2, 3, 8, 'USD', 8, 0, 6000, 'NGN', '2023-07-31 23:52:21', 'declined', 1),
(3, 2, 1333.33, 'USD', 1333.33, 0, 1000000, 'NGN', '2023-08-01 06:03:37', 'approved', 1),
(4, 1, 1.6, 'USD', 1.6, 0, 1200, 'NGN', '2023-08-01 21:50:22', 'approved', 1),
(5, 1, 1.45, 'USD', 1.45, 0, 1090, 'NGN', '2023-08-01 22:08:24', 'declined', 0),
(6, 2, 266.66, 'USD', 266.66, 0, 200000, 'NGN', '2023-08-01 22:49:21', 'approved', 1),
(7, 1, 1, 'USD', 1, 0, 750, 'NGN', '2023-08-05 23:42:07', 'approved', 1),
(8, 1, 1, 'USD', 1, 0, 3.64, 'AED', '2023-08-05 23:43:06', 'approved', 1),
(9, 1, 3.64, 'AED', 1, 0, 1, 'USD', '2023-08-05 23:44:07', 'approved', 1),
(10, 2, 266, 'USD', 266, 0, 199500, 'NGN', '2023-08-06 07:52:13', 'approved', 1),
(11, 15, 12000, 'USD', 12000, 120, 9504, 'GBP', '2023-08-14 10:37:42', 'declined', 0);

-- --------------------------------------------------------

--
-- Table structure for table `uss_loans`
--

CREATE TABLE `uss_loans` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `amount` float DEFAULT NULL,
  `duration` varchar(20) NOT NULL,
  `loan_type` varchar(50) NOT NULL,
  `reason` text DEFAULT NULL,
  `loan_id` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `funded` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `uss_loans`
--

INSERT INTO `uss_loans` (`id`, `userid`, `date`, `amount`, `duration`, `loan_type`, `reason`, `loan_id`, `status`, `funded`) VALUES
(1, 2, '2023-07-31 10:02:42', 3000000, '1 year', 'business loan', '', 'buhzd5', 'approved', 1),
(2, 15, '2023-08-14 10:35:04', 30000, '1 month', 'business loan', 'To grow my business', 'rk2yez', 'approved', 1);

-- --------------------------------------------------------

--
-- Table structure for table `uss_notifications`
--

CREATE TABLE `uss_notifications` (
  `id` int(11) NOT NULL,
  `origin` int(11) DEFAULT NULL,
  `model` varchar(100) DEFAULT NULL COMMENT 'TYPE: Comment, Reply, Module-Name...',
  `userid` int(11) NOT NULL,
  `period` timestamp NOT NULL DEFAULT current_timestamp(),
  `message` varchar(5000) DEFAULT NULL,
  `viewed` tinyint(4) NOT NULL DEFAULT 0,
  `redirect` varchar(255) DEFAULT NULL COMMENT 'URL',
  `image` varchar(255) DEFAULT NULL,
  `hidden` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `uss_notifications`
--

INSERT INTO `uss_notifications` (`id`, `origin`, `model`, `userid`, `period`, `message`, `viewed`, `redirect`, `image`, `hidden`) VALUES
(1, NULL, 'bank:transfer', 9, '2023-08-11 10:35:36', 'Hi Uchenna,  \nThis is to notify you that an amount of 10.00 USD has been debited from your account.  \nAcc: 104***399  \nDesc:   \nTime: 11/08/2023  \nTotal Bal: 220.00 USD  \nAvail Bal: 209.00 USD', 1, 'https://scriptstesters.website/aa-bank/dashboard/receipt/64d60ef838e6aFJROBBZ1ghqYstG', NULL, 0),
(2, NULL, 'bank:transfer', 9, '2023-08-11 10:40:04', 'Hi Uchenna,  \nThis is to notify you that an amount of 99.00 USD has been debited from your account.  \nAcc: 104***399  \nDesc:   \nTime: 11/08/2023  \nTotal Bal: 209.00 USD  \nAvail Bal: 100.10 USD', 0, 'https://scriptstesters.website/aa-bank/dashboard/receipt/64d61004580b2ktbzy9oT7B8m0Az', NULL, 0),
(3, NULL, 'bank:transfer', 3, '2023-08-11 14:45:02', 'Hi Paul,  \nThis is to notify you that an amount of 50,000.00 USD has been debited from your account.  \nAcc: 104***995  \nDesc: yeah from admin  \nTime: 11/08/2023  \nTotal Bal: 18,308.00 USD  \nAvail Bal: -31,692.00 USD', 0, 'https://scriptstesters.website/aa-bank/dashboard/receipt/64d6496e8727aypII0ByxYPyYWnw', NULL, 0),
(4, NULL, 'bank:transfer', 3, '2023-08-11 14:45:43', 'Hi Paul,  \nThis is to notify you that an amount of 100,000.00 USD has been credited to your account.  \nAcc: 104***995  \nDesc: again  \nTime: 11/08/2023  \nTotal Bal: -31,692.00 USD  \nAvail Bal: -131,692.00 USD', 0, 'https://scriptstesters.website/aa-bank/dashboard/receipt/64d6499752509YhzsARjb3edWA3m', NULL, 0),
(5, NULL, 'bank:transfer', 3, '2023-08-11 14:50:00', 'Hi Paul,  \nThis is to notify you that an amount of 2,000.00 USD has been debited from your account.  \nAcc: 104***995  \nDesc: test  \nTime: 11/08/2023  \nTotal Bal: 68,308.00 USD  \nAvail Bal: 66,108.00 USD', 0, 'https://scriptstesters.website/aa-bank/dashboard/receipt/64d64a98eb8d1jKVJpi4psCABoWt', NULL, 0),
(6, NULL, 'bank:transfer', 1, '2023-08-11 14:57:39', 'Hi Admin,  \nThis is to notify you that an amount of 1.00 USD has been debited from your account.  \nAcc: 104***848  \nDesc:   \nTime: 11/08/2023  \nTotal Bal: 2.65 USD  \nAvail Bal: 1.55 USD', 1, 'https://scriptstesters.website/aa-bank/dashboard/receipt/64d64c638a3441ARGVNM0plk4vSR', NULL, 0),
(7, NULL, 'bank:transfer', 1, '2023-08-13 07:04:18', 'Hi Admin,  \nThis is to notify you that an amount of 1.00 USD has been debited from your account.  \nAcc: 104***848  \nDesc:   \nTime: 13/08/2023  \nTotal Bal: 1.55 USD  \nAvail Bal: 0.45 USD', 1, 'https://scriptstesters.website/aa-bank/dashboard/receipt/64d880725273c7YGpUhnECc12NLT', NULL, 0),
(8, NULL, 'bank:transfer', 1, '2023-08-13 07:06:38', 'Hi Admin,  \nThis is to notify you that an amount of 10.00 GBP has been credited to your account.  \nAcc: 104***848  \nDesc:   \nTime: 13/08/2023  \nTotal Bal: 0.00 GBP  \nAvail Bal: -10.00 GBP', 1, 'https://scriptstesters.website/aa-bank/dashboard/receipt/64d880fee2e91gbbcy4ddNsOVsKI', NULL, 0),
(9, NULL, 'bank:transfer', 1, '2023-08-13 07:06:56', 'Hi Admin,  \nThis is to notify you that an amount of 25.70 USD has been credited to your account.  \nAcc: 104***848  \nDesc:   \nTime: 13/08/2023  \nTotal Bal: 0.45 USD  \nAvail Bal: -25.25 USD', 1, 'https://scriptstesters.website/aa-bank/dashboard/receipt/64d88110e425eYwwOVauO3FWjKOU', NULL, 0),
(10, NULL, 'bank:transfer', 11, '2023-08-13 19:35:30', 'Hi Uchenna,  \nThis is to notify you that an amount of 1,200.00 USD has been credited to your account.  \nAcc: 104***157  \nDesc:   \nTime: 13/08/2023  \nTotal Bal: 0.00 USD  \nAvail Bal: -1,200.00 USD', 1, 'https://scriptstesters.website/aa-bank/dashboard/receipt/64d9308288768lkZnrY4HryQiJyL', NULL, 0),
(11, NULL, 'bank:transfer', 15, '2023-08-14 10:20:37', 'Hi Paul,  \nThis is to notify you that an amount of 50,000.00 USD has been credited to your account.  \nAcc: 104***043  \nDesc: From admin testing  \nTime: 14/08/2023  \nTotal Bal: 0.00 USD  \nAvail Bal: -50,000.00 USD', 0, 'https://scriptstesters.website/aa-bank/dashboard/receipt/64d9fff5cfe888n837JTIJbBKgZ7', NULL, 0),
(12, NULL, 'bank:transfer', 15, '2023-08-14 10:27:46', 'Hi Paul,  \nThis is to notify you that an amount of 10,000.00 USD has been debited from your account.  \nAcc: 104***043  \nDesc: First transfer  \nTime: 14/08/2023  \nTotal Bal: 50,000.00 USD  \nAvail Bal: 39,000.00 USD', 1, 'https://scriptstesters.website/aa-bank/dashboard/receipt/64da01a26b2e4dGZBHZIPNuzfVDM', NULL, 0),
(13, NULL, 'bank:transfer', 15, '2023-08-14 10:35:33', 'Hi Paul,  \nThis is to notify you that an amount of 30,000.00 USD has been credited to your account.  \nAcc: 104***043  \nDesc:   \nTime: 14/08/2023  \nTotal Bal: 64,000.00 USD  \nAvail Bal: 34,000.00 USD', 0, 'https://scriptstesters.website/aa-bank/dashboard/receipt/64da037548d639OUHDekiHxWZ2ww', NULL, 0),
(14, NULL, 'bank:transfer', 15, '2023-08-14 10:37:42', 'Hi Paul,  \nThis is to notify you that an amount of 12,000.00 USD has been debited from your account.  \nAcc: 104***043  \nDesc:   \nTime: 14/08/2023  \nTotal Bal: 94,000.00 USD  \nAvail Bal: 82,000.00 USD', 0, 'https://scriptstesters.website/aa-bank/dashboard/receipt/64da03f64edb7PngUMD2ktuAXm6F', NULL, 0),
(15, NULL, 'bank:transfer', 15, '2023-08-14 10:40:19', 'Hi Paul,  \nThis is to notify you that an amount of 200,000.00 NGN has been credited to your account.  \nAcc: 104***043  \nDesc: naira from admin  \nTime: 14/08/2023  \nTotal Bal: 0.00 NGN  \nAvail Bal: -200,000.00 NGN', 0, 'https://scriptstesters.website/aa-bank/dashboard/receipt/64da0493ee3feJ0JITeMjKW7RdSC', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `uss_options`
--

CREATE TABLE `uss_options` (
  `id` int(11) NOT NULL,
  `_ref` int(11) DEFAULT NULL,
  `_key` varchar(255) NOT NULL,
  `_value` text DEFAULT NULL,
  `epoch` bigint(20) NOT NULL DEFAULT unix_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `uss_options`
--

INSERT INTO `uss_options` (`id`, `_ref`, `_key`, `_value`, `epoch`) VALUES
(1, NULL, 'user:disable-signup', '\"0\"', 1690407089),
(2, NULL, 'user:collect-username', '\"1\"', 1690407089),
(3, NULL, 'user:confirm-email', '\"0\"', 1690407089),
(4, NULL, 'user:lock-email', '\"0\"', 1690407089),
(5, NULL, 'user:reconfirm-email', '\"0\"', 1690407089),
(6, NULL, 'user:default-role', '\"member\"', 1690407089),
(7, NULL, 'user:affiliation', '\"0\"', 1690407089),
(8, NULL, 'user:auto-trash-unverified-after-day', '\"7\"', 1690407089),
(9, NULL, 'email:admin', '\"admin@yourdomain.com\"', 1690407089),
(10, NULL, 'smtp:state', '\"default\"', 1690407089),
(11, NULL, 'bank:currencies', '[{\"code\":\"USD\",\"name\":\"US Dollar\",\"symbol\":\"$\",\"rate\":1},{\"code\":\"GBP\",\"name\":\"Pound Sterling\",\"symbol\":\"\\u00a3\",\"rate\":\"0.8\"},{\"code\":\"NGN\",\"name\":\"Naira\",\"symbol\":\"\\u20a6\",\"rate\":\"800\"}]', 1690407089),
(12, NULL, 'bank:currencies.default', '\"USD\"', 1690407089),
(13, NULL, 'bank:accounts', '[\"savings account\",\"current account\",\"fixed account\",\"non resident account\"]', 1690407089),
(14, NULL, 'bank:transfer.charge', '\"0\"', 1690407089),
(15, NULL, 'bank:transfer.codes', '[{\"imf\":\"7325\"},{\"cot\":2349},{\"tax\":\"3427\"}]', 1690407089),
(16, NULL, 'site:phone', '\"1234567890\"', 1690407089),
(17, NULL, 'site:address', '\"Your bank address will be here...\"', 1690407089),
(18, NULL, 'site:exchange-fee', '\"20\"', 1690407089),
(23, NULL, 'email:from', '\"\"', 1692003209),
(19, NULL, 'site:title', '\"Alpha Bank\"', 1690632719),
(20, NULL, 'site:tagline', '\"Welcome To Alpha Bank\"', 1690632719),
(21, NULL, 'site:description', '\"Alpha Bank (P.J.S.C) is licensed by the Central Bank of the Alpha\"', 1690632719),
(22, NULL, 'site:icon', '\"uss-dashboard-main\\/ud-assets\\/images\\/general\\/7d4b83c9fc2bc05690ebc9008015b096c10dd5c1.png\"', 1690632719);

-- --------------------------------------------------------

--
-- Table structure for table `uss_payment_methods`
--

CREATE TABLE `uss_payment_methods` (
  `id` int(11) NOT NULL,
  `medium` varchar(20) NOT NULL DEFAULT 'crypto' COMMENT 'crypto,bank,other',
  `network` varchar(100) DEFAULT NULL COMMENT 'ETH, BTC',
  `name` varchar(255) NOT NULL,
  `icon` varchar(100) DEFAULT NULL,
  `detail` text DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` tinyint(4) NOT NULL DEFAULT 1
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `uss_payment_methods`
--

INSERT INTO `uss_payment_methods` (`id`, `medium`, `network`, `name`, `icon`, `detail`, `date`, `status`) VALUES
(1, 'crypto', 'BTC', 'Bitcoin', 'uss-bank/bank-admin/gateway/images/c4bcfa7ee9d7f7327e579330f66d13a57c92b012.png', '{\"bitcoin_wallet\":\"bc1q8r2n40q3h57vl7hfl50exqaa6gnjgf9g428pgg\"}', '2023-08-12 23:30:22', 1);

-- --------------------------------------------------------

--
-- Table structure for table `uss_transfers`
--

CREATE TABLE `uss_transfers` (
  `id` int(11) NOT NULL,
  `amount` float NOT NULL DEFAULT 0,
  `currency` varchar(3) NOT NULL DEFAULT 'USD',
  `tx_ref` varchar(50) NOT NULL,
  `tx_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `tx_reason` varchar(1000) DEFAULT NULL,
  `tx_region` varchar(20) NOT NULL DEFAULT 'local',
  `tx_charge` float NOT NULL DEFAULT 0 COMMENT '%',
  `tx_status` varchar(20) NOT NULL DEFAULT 'success',
  `bank_country` varchar(3) DEFAULT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  `bank_account` varchar(20) DEFAULT NULL,
  `bank_holder` varchar(255) DEFAULT NULL,
  `identifier` varchar(100) DEFAULT NULL,
  `identifier_code` varchar(100) DEFAULT NULL,
  `sender_name` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `uss_transfers`
--

INSERT INTO `uss_transfers` (`id`, `amount`, `currency`, `tx_ref`, `tx_date`, `tx_reason`, `tx_region`, `tx_charge`, `tx_status`, `bank_country`, `bank_name`, `bank_account`, `bank_holder`, `identifier`, `identifier_code`, `sender_name`) VALUES
(51, 1200, 'USD', '64d9308288768lkZnrY4HryQiJyL', '2023-08-13 19:35:30', '', 'local', 0, 'success', NULL, 'Emirates NBD', '1041159157', 'Uchenna Ajah', NULL, NULL, 'Unverified'),
(52, 50000, 'USD', '64d9fff5cfe888n837JTIJbBKgZ7', '2023-08-14 10:20:37', 'From admin testing', 'local', 0, 'success', NULL, 'Alpha Bank', '1041577043', 'Paul Smith', NULL, NULL, 'Unverified'),
(53, 10000, 'USD', '64da01a26b2e4dGZBHZIPNuzfVDM', '2023-08-14 10:27:46', 'First transfer', 'international', 10, 'success', 'AU', 'FCMB', '1234567890', 'Boss Man', 'Routing Number / Bank Code', '12345', NULL),
(57, 200000, 'NGN', '64da0493ee3feJ0JITeMjKW7RdSC', '2023-08-14 10:40:19', 'naira from admin', 'local', 0, 'success', NULL, 'Alpha Bank', '1041577043', 'Paul Smith', NULL, NULL, 'Unverified');

-- --------------------------------------------------------

--
-- Table structure for table `uss_transfer_meta`
--

CREATE TABLE `uss_transfer_meta` (
  `id` int(11) NOT NULL,
  `tx_ref` varchar(50) NOT NULL,
  `account_number` varchar(20) DEFAULT NULL,
  `tx_type` varchar(20) NOT NULL COMMENT 'debit|credit',
  `amount` float NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `uss_transfer_meta`
--

INSERT INTO `uss_transfer_meta` (`id`, `tx_ref`, `account_number`, `tx_type`, `amount`, `status`) VALUES
(65, '64d9308288768lkZnrY4HryQiJyL', '1041159157', 'credit', 1200, 1),
(66, '64d9fff5cfe888n837JTIJbBKgZ7', '1041577043', 'credit', 50000, 1),
(67, '64da01a26b2e4dGZBHZIPNuzfVDM', '1234567890', 'credit', 10000, 1),
(68, '64da01a26b2e4dGZBHZIPNuzfVDM', '1041577043', 'debit', 11000, 1),
(72, '64da0493ee3feJ0JITeMjKW7RdSC', '1041577043', 'credit', 200000, 1);

-- --------------------------------------------------------

--
-- Table structure for table `uss_usermeta`
--

CREATE TABLE `uss_usermeta` (
  `id` int(11) NOT NULL,
  `_ref` int(11) NOT NULL,
  `_key` varchar(255) NOT NULL,
  `_value` text DEFAULT NULL,
  `epoch` bigint(20) NOT NULL DEFAULT unix_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `uss_usermeta`
--

INSERT INTO `uss_usermeta` (`id`, `_ref`, `_key`, `_value`, `epoch`) VALUES
(1, 1, 'roles', '[\"member\",\"super-admin\"]', 1690408064),
(2, 1, 'bank:info', '{\"security\":{\"pin\":\"1111\"},\"bio\":{\"firstname\":\"Admin\",\"lastname\":\"Boss\",\"phone\":\"1234567890\",\"birthdate\":\"1997-02-05\",\"gender\":\"male\",\"religion\":\"others\"},\"address\":{\"location\":\"This is my address here\",\"state\":\"Califonia\",\"city\":\"LA\",\"country\":\"AF\",\"zipcode\":\"1230001\"},\"nok\":{\"firstname\":\"Paul\",\"lastname\":\"Smith\",\"relationship\":\"friend\",\"address\":\"NOK address here\"},\"system\":{\"currency\":\"USD\",\"account\":\"current account\"}}', 1690408064),
(3, 1, 'bank:balance', '26.15', 1690408064),
(4, 1, 'bank:number', '\"1041430848\"', 1690408064),
(5, 1, 'bank:otp', '{\"email\":\"0\",\"transfer_code\":\"0\"}', 1690408064),
(6, 1, 'bank:account', '{\"verified\":\"1\",\"can-transfer\":\"1\"}', 1690408064),
(7, 1, 'bank:extra', '[]', 1690408064),
(8, 2, 'roles', '[\"member\"]', 1690796408),
(9, 2, 'bank:info', '{\"security\":{\"pin\":\"8080\"},\"bio\":{\"firstname\":\"Jeff\",\"lastname\":\"Olsen\",\"phone\":\"\",\"birthdate\":\"1964-03-31\",\"gender\":\"male\",\"religion\":\"christianity\"},\"address\":{\"location\":\"Earth\",\"state\":\"World\",\"city\":\"Ah\",\"country\":\"AU\",\"zipcode\":\"90001\"},\"nok\":{\"firstname\":\"Justin\",\"lastname\":\"Olsen\",\"relationship\":\"sister\",\"address\":\"Delete\"},\"system\":{\"currency\":\"USD\",\"account\":\"savings account\"}}', 1690796408),
(10, 2, 'bank:balance', '2998134.003', 1690796408),
(11, 2, 'bank:number', '\"1042599871\"', 1690796408),
(12, 2, 'bank:otp', '{\"email\":0,\"transfer_code\":0}', 1690796408),
(13, 2, 'bank:account', '{\"verified\":1,\"can-transfer\":1}', 1690796408),
(14, 2, 'bank:extra', '[]', 1690796408),
(15, 3, 'roles', '[\"member\"]', 1690845370),
(16, 3, 'bank:info', '{\"security\":{\"pin\":\"1111\"},\"bio\":{\"firstname\":\"Paul\",\"lastname\":\"Smith\",\"phone\":\"1234567890\",\"birthdate\":\"2023-08-10\",\"gender\":\"female\",\"religion\":\"christianity\"},\"address\":{\"location\":\"ring road\",\"state\":\"Lagos\",\"city\":\"Ikeja\",\"country\":\"AU\",\"zipcode\":\"100001\"},\"nok\":{\"firstname\":\"Kin\",\"lastname\":\"Ben\",\"relationship\":\"friend\",\"address\":\"Agege Lagos\"},\"system\":{\"currency\":\"USD\",\"account\":\"current account\"}}', 1690845370),
(17, 3, 'bank:balance', '66108', 1690845370),
(18, 3, 'bank:number', '\"1043345995\"', 1690845370),
(19, 3, 'bank:otp', '{\"email\":\"0\",\"transfer_code\":\"0\"}', 1690845370),
(20, 3, 'bank:account', '{\"verified\":\"1\",\"can-transfer\":\"1\"}', 1690845370),
(21, 3, 'bank:extra', '[]', 1690845370),
(22, 3, 'bank:balance.NGN', '9000', 1690847449),
(23, 1, 'bank:balance.NGN', '1950', 1690926866),
(24, 3, 'avatar', '\"uss-dashboard-main\\/ud-assets\\/images\\/profile\\/3-50c1bd367c94bda5e728dbd8a2400d9a6782c635.jpg\"', 1691151000),
(25, 4, 'roles', '[\"member\"]', 1691156168),
(26, 4, 'bank:info', '{\"security\":{\"pin\":\"1111\"},\"bio\":{\"firstname\":\"Ben\",\"lastname\":\"Tola\",\"phone\":\"12345678\",\"birthdate\":\"2023-08-23\",\"gender\":\"others\",\"religion\":\"others\"},\"address\":{\"location\":\"weg5y46\",\"state\":\"t56\",\"city\":\"ety64u\",\"country\":\"AX\",\"zipcode\":\"876541\"},\"nok\":{\"firstname\":\"Ben\",\"lastname\":\"Smith\",\"relationship\":\"brother\",\"address\":\"wef tht4\"},\"system\":{\"currency\":\"NGN\",\"account\":\"current account\"}}', 1691156168),
(27, 4, 'bank:balance', '0', 1691156168),
(28, 4, 'bank:number', '\"1044691555\"', 1691156168),
(29, 4, 'bank:otp', '{\"email\":\"0\",\"transfer_code\":\"0\"}', 1691156168),
(30, 4, 'bank:account', '{\"verified\":\"0\",\"can-transfer\":\"0\"}', 1691156168),
(31, 4, 'bank:extra', '[]', 1691156168),
(32, 5, 'roles', '[\"member\"]', 1691172511),
(33, 5, 'bank:info', '{\"security\":{\"pin\":\"1983\"},\"bio\":{\"firstname\":\"Manu\",\"lastname\":\"Suresh\",\"phone\":\"053646382\",\"birthdate\":\"1983-08-17\",\"gender\":\"male\",\"religion\":\"others\"},\"address\":{\"location\":\"116 Konappana Agarhara G S Palya Cross Hosur Road Electronic City\",\"state\":\"Karnataka\",\"city\":\"Bangalore\",\"country\":\"IN\",\"zipcode\":\"560100\"},\"nok\":{\"firstname\":\"Likitha\",\"lastname\":\"Prabhakar Reddy\",\"relationship\":\"spouse\",\"address\":\"116 Konappana Agarhara G S Palya Cross Hosur Road Electronic City\"},\"system\":{\"currency\":\"AED\",\"account\":\"non resident account\"}}', 1691172511),
(34, 5, 'bank:balance', '5286337395.6', 1691172511),
(35, 5, 'bank:number', '\"1045206371\"', 1691172511),
(36, 5, 'bank:otp', '{\"email\":\"1\",\"transfer_code\":\"1\"}', 1691172511),
(37, 5, 'bank:account', '{\"verified\":\"1\",\"can-transfer\":\"1\"}', 1691172511),
(38, 5, 'bank:extra', '[]', 1691172511),
(39, 1, 'bank:balance.AED', '0', 1691279027),
(40, 6, 'roles', '[\"member\"]', 1691314638),
(42, 6, 'bank:info', '{\"security\":{\"pin\":\"5498\"},\"bio\":{\"firstname\":\"JACKSON\",\"lastname\":\"Wook\",\"phone\":\"9254055563\",\"birthdate\":\"1970-01-23\",\"gender\":\"male\",\"religion\":\"christianity\"},\"address\":{\"location\":\"USA\",\"state\":\"New York\",\"city\":\"NY\",\"country\":\"US\",\"zipcode\":\"10011\"},\"nok\":{\"firstname\":\"Jackson\",\"lastname\":\"Wook\",\"relationship\":\"father\",\"address\":\"USA\"},\"system\":{\"currency\":\"USD\",\"account\":\"current account\"}}', 1691314638),
(43, 6, 'bank:balance', '2633100', 1691314638),
(44, 6, 'bank:number', '\"1046798542\"', 1691314638),
(45, 6, 'bank:otp', '{\"email\":\"1\",\"transfer_code\":\"1\"}', 1691314638),
(46, 6, 'bank:account', '{\"verified\":\"1\",\"can-transfer\":\"1\"}', 1691314638),
(47, 6, 'bank:extra', '[]', 1691314638),
(48, 6, 'bank:balance.AED', '848799', 1691316364),
(49, 6, 'avatar', '\"uss-dashboard-main\\/ud-assets\\/images\\/profile\\/6-b4b8529d446c2167f6634a26341d97f1398438c6.jpeg\"', 1691316528),
(50, 2, 'bank:balance.NGN', '1399500', 1691323256),
(51, 7, 'roles', '[\"member\"]', 1691332962),
(53, 7, 'bank:info', '{\"security\":{\"pin\":\"1975\"},\"bio\":{\"firstname\":\"Babu\",\"lastname\":\"Chetty\",\"phone\":\"7259245187\",\"birthdate\":\"1975-02-03\",\"gender\":\"male\",\"religion\":\"others\"},\"address\":{\"location\":\"273 Munireddy BLDG Opp Velankani IT Doddathogur\",\"state\":\"Karnataka\",\"city\":\"Bangalore\",\"country\":\"IN\",\"zipcode\":\"560100\"},\"nok\":{\"firstname\":\"Chandrakala\",\"lastname\":\"Babu\",\"relationship\":\"spouse\",\"address\":\"273 Munireddy BLDG Opp Velankani IT Doddathogur\"},\"system\":{\"currency\":\"AED\",\"account\":\"non resident account\"}}', 1691332962),
(54, 7, 'bank:balance', '\"16049378236\"', 1691332962),
(55, 7, 'bank:number', '\"1047172440\"', 1691332962),
(56, 7, 'bank:otp', '{\"email\":\"1\",\"transfer_code\":\"1\"}', 1691332962),
(57, 7, 'bank:account', '{\"verified\":\"1\",\"can-transfer\":\"1\"}', 1691332962),
(58, 7, 'bank:extra', '[]', 1691332962),
(59, 7, 'bank:balance.AED', '71428660000', 1691333453),
(60, 8, 'roles', '[\"member\"]', 1691439345),
(61, 8, 'bank:info', '{\"security\":{\"pin\":\"1234\"},\"bio\":{\"firstname\":\"Frank\",\"lastname\":\"John\",\"phone\":\"08076463165\",\"birthdate\":\"2023-08-25\",\"gender\":\"male\",\"religion\":\"christianity\"},\"address\":{\"location\":\"Usa\",\"state\":\"Neami\",\"city\":\"State\",\"country\":\"AQ\",\"zipcode\":\"2365\"},\"nok\":{\"firstname\":\"John\",\"lastname\":\"Last\",\"relationship\":\"brother\",\"address\":\"Yeiebdbdbfj\"},\"system\":{\"currency\":\"USD\",\"account\":\"savings account\"}}', 1691439346),
(62, 8, 'bank:balance', '\"450000\"', 1691439346),
(63, 8, 'bank:number', '\"1048663618\"', 1691439346),
(64, 8, 'bank:otp', '{\"email\":0,\"transfer_code\":0}', 1691439346),
(65, 8, 'bank:account', '{\"verified\":0,\"can-transfer\":0}', 1691439346),
(66, 8, 'bank:extra', '[]', 1691439346),
(67, 8, 'avatar', '\"uss-dashboard-main\\/ud-assets\\/images\\/profile\\/8-c8130a837b408c6cf41ca8816ba438c97d469940.jpg\"', 1691439501),
(68, 9, 'roles', '[\"member\"]', 1691749981),
(69, 9, 'bank:info', '{\"security\":{\"pin\":\"1234\"},\"bio\":{\"firstname\":\"Uchenna\",\"lastname\":\"Ajah\",\"phone\":\"08125858560\",\"birthdate\":\"2023-08-16\",\"gender\":\"male\",\"religion\":\"christianity\"},\"address\":{\"location\":\"293 agege motor road\",\"state\":\"Lagos\",\"city\":\"Mushin\",\"country\":\"GB\",\"zipcode\":\"100253\"},\"nok\":{\"firstname\":\"\",\"lastname\":\"\",\"relationship\":\"\",\"address\":\"\"},\"system\":{\"currency\":\"USD\",\"account\":\"non resident account\"}}', 1691749981),
(70, 9, 'bank:balance', '100.1', 1691749981),
(71, 9, 'bank:number', '\"1049808399\"', 1691749981),
(72, 9, 'bank:otp', '{\"email\":0,\"transfer_code\":0}', 1691749981),
(73, 9, 'bank:account', '{\"verified\":1,\"can-transfer\":1}', 1691749981),
(74, 9, 'bank:extra', '[]', 1691749981),
(75, 10, 'roles', '[\"member\"]', 1691771608),
(76, 10, 'bank:info', '{\"security\":{\"pin\":\"1234\"},\"bio\":{\"firstname\":\"Frank\",\"lastname\":\"Aig\",\"phone\":\"08074653218\",\"birthdate\":\"2023-08-30\",\"gender\":\"male\",\"religion\":\"christianity\"},\"address\":{\"location\":\"22 Sapkonba riad\",\"state\":\"Edo state\",\"city\":\"Bein city\",\"country\":\"NG\",\"zipcode\":\"234\"},\"nok\":{\"firstname\":\"Alex\",\"lastname\":\"Look\",\"relationship\":\"brother\",\"address\":\"22 Toyota Camry\"},\"system\":{\"currency\":\"GBP\",\"account\":\"current account\"}}', 1691771608),
(77, 10, 'bank:balance', '0', 1691771608),
(78, 10, 'bank:number', '\"1041072857\"', 1691771608),
(79, 10, 'bank:otp', '{\"email\":0,\"transfer_code\":0}', 1691771608),
(80, 10, 'bank:account', '{\"verified\":0,\"can-transfer\":0}', 1691771608),
(81, 10, 'bank:extra', '[]', 1691771608),
(82, 1, 'bank:balance.GBP', '10', 1691910416),
(83, 11, 'roles', '[\"member\",\"administrator\"]', 1691955177),
(84, 11, 'bank:info', '{\"security\":{\"pin\":\"1234\"},\"bio\":{\"firstname\":\"Uchenna\",\"lastname\":\"Ajah\",\"phone\":\"09122065408\",\"birthdate\":\"2023-08-16\",\"gender\":\"male\",\"religion\":\"christianity\"},\"address\":{\"location\":\"293 agege motor road\",\"state\":\"Lagos\",\"city\":\"Mushin\",\"country\":\"NG\",\"zipcode\":\"100253\"},\"nok\":{\"firstname\":\"\",\"lastname\":\"\",\"relationship\":\"\",\"address\":\"\"},\"system\":{\"currency\":\"USD\",\"account\":\"current account\"}}', 1691955177),
(85, 11, 'bank:balance', '\"1200\"', 1691955177),
(86, 11, 'bank:number', '\"1041159157\"', 1691955177),
(87, 11, 'bank:otp', '{\"email\":\"0\",\"transfer_code\":\"0\"}', 1691955177),
(88, 11, 'bank:account', '{\"verified\":\"1\",\"can-transfer\":\"1\"}', 1691955177),
(89, 11, 'bank:extra', '[]', 1691955177),
(90, 12, 'roles', '[\"member\"]', 1692005450),
(91, 12, 'bank:info', '{\"security\":{\"pin\":\"1111\"},\"bio\":{\"firstname\":\"Paul\",\"lastname\":\"Smith\",\"phone\":\"098765432\",\"birthdate\":\"2013-01-09\",\"gender\":\"male\",\"religion\":\"christianity\"},\"address\":{\"location\":\"23 Arumo Close\",\"state\":\"FCT\",\"city\":\"Abuja\",\"country\":\"NG\",\"zipcode\":\"122111\"},\"nok\":{\"firstname\":\"\",\"lastname\":\"\",\"relationship\":\"\",\"address\":\"\"},\"system\":{\"currency\":\"USD\",\"account\":\"savings account\"}}', 1692005450),
(92, 12, 'bank:balance', '0', 1692005450),
(93, 12, 'bank:number', '\"1041239679\"', 1692005450),
(94, 12, 'bank:otp', '{\"email\":\"0\",\"transfer_code\":\"0\"}', 1692005450),
(95, 12, 'bank:account', '{\"verified\":\"1\",\"can-transfer\":\"0\"}', 1692005450),
(96, 12, 'bank:extra', '[]', 1692005450),
(97, 13, 'roles', '[\"member\"]', 1692006511),
(99, 13, 'bank:info', '{\"security\":{\"pin\":\"1111\"},\"bio\":{\"firstname\":\"Paul\",\"lastname\":\"Smith\",\"phone\":\"1234567890\",\"birthdate\":\"2023-08-16\",\"gender\":\"male\",\"religion\":\"christianity\"},\"address\":{\"location\":\"23 Arumo Close\",\"state\":\"FCT\",\"city\":\"Abuja\",\"country\":\"NG\",\"zipcode\":\"123001\"},\"nok\":{\"firstname\":\"\",\"lastname\":\"\",\"relationship\":\"\",\"address\":\"\"},\"system\":{\"currency\":\"USD\",\"account\":\"savings account\"}}', 1692006511),
(100, 13, 'bank:balance', '0', 1692006511),
(101, 13, 'bank:number', '\"1041359536\"', 1692006511),
(102, 13, 'bank:otp', '{\"email\":\"0\",\"transfer_code\":\"0\"}', 1692006511),
(103, 13, 'bank:account', '{\"verified\":\"1\",\"can-transfer\":\"0\"}', 1692006511),
(104, 13, 'bank:extra', '[]', 1692006511),
(105, 14, 'roles', '[\"member\"]', 1692007437),
(106, 14, 'v-code', '\"mBtBzdpbvPY0l3tZ3YYVqoRYgzPngdBl\"', 1692007437),
(107, 14, 'bank:info', '{\"security\":{\"pin\":\"1111\"},\"bio\":{\"firstname\":\"Paul\",\"lastname\":\"Smith\",\"phone\":\"1234567890\",\"birthdate\":\"2023-08-08\",\"gender\":\"male\",\"religion\":\"others\"},\"address\":{\"location\":\"23 Arumo Close\",\"state\":\"FCT\",\"city\":\"Abuja\",\"country\":\"NG\",\"zipcode\":\"100001\"},\"nok\":{\"firstname\":\"\",\"lastname\":\"\",\"relationship\":\"\",\"address\":\"\"},\"system\":{\"currency\":\"USD\",\"account\":\"savings account\"}}', 1692007437),
(108, 14, 'bank:balance', '0', 1692007437),
(109, 14, 'bank:number', '\"1041442900\"', 1692007437),
(110, 14, 'bank:otp', '{\"email\":0,\"transfer_code\":0}', 1692007437),
(111, 14, 'bank:account', '{\"verified\":0,\"can-transfer\":0}', 1692007437),
(112, 14, 'bank:extra', '[]', 1692007437),
(113, 15, 'roles', '[\"member\"]', 1692008296),
(114, 15, 'bank:info', '{\"security\":{\"pin\":\"1111\"},\"bio\":{\"firstname\":\"Paul\",\"lastname\":\"Smith\",\"phone\":\"1234567890\",\"birthdate\":\"2023-08-06\",\"gender\":\"male\",\"religion\":\"others\"},\"address\":{\"location\":\"23 Arumo Close\",\"state\":\"FCT\",\"city\":\"Abuja\",\"country\":\"NG\",\"zipcode\":\"100211\"},\"nok\":{\"firstname\":\"\",\"lastname\":\"\",\"relationship\":\"\",\"address\":\"\"},\"system\":{\"currency\":\"USD\",\"account\":\"savings account\"}}', 1692008296),
(115, 15, 'bank:balance', '82000', 1692008296),
(116, 15, 'bank:number', '\"1041577043\"', 1692008296),
(117, 15, 'bank:otp', '{\"email\":\"1\",\"transfer_code\":\"1\"}', 1692008296),
(118, 15, 'bank:account', '{\"verified\":\"1\",\"can-transfer\":\"1\",\"kyc\":\"uss-bank\\/bank-client\\/account\\/images\\/kyc\\/b7c8704d4026e052cd25049a18be9b6530a17233.jpg\"}', 1692008296),
(119, 15, 'bank:extra', '[]', 1692008296),
(120, 15, 'bank:balance.NGN', '200000', 1692009627);

-- --------------------------------------------------------

--
-- Table structure for table `uss_users`
--

CREATE TABLE `uss_users` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(25) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `register_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `usercode` varchar(12) NOT NULL,
  `last_seen` timestamp NOT NULL DEFAULT current_timestamp(),
  `parent` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `uss_users`
--

INSERT INTO `uss_users` (`id`, `email`, `username`, `password`, `register_time`, `usercode`, `last_seen`, `parent`) VALUES
(1, 'admin@yourdomain.com', NULL, '$2y$10$voXu4jQvF4Qf3I2sd/ofV.Rd/m2D.w10oRWoFhuA0j5PnBBgnKY4C', '2023-07-26 21:47:44', '7HaRw', '2023-07-26 21:47:44', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `uss_beneficiaries`
--
ALTER TABLE `uss_beneficiaries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userid` (`userid`);

--
-- Indexes for table `uss_cards`
--
ALTER TABLE `uss_cards`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userid` (`userid`);

--
-- Indexes for table `uss_cheques`
--
ALTER TABLE `uss_cheques`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uss_deposits`
--
ALTER TABLE `uss_deposits`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tx_ref` (`tx_ref`);

--
-- Indexes for table `uss_exchanges`
--
ALTER TABLE `uss_exchanges`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uss_loans`
--
ALTER TABLE `uss_loans`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uss_notifications`
--
ALTER TABLE `uss_notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userid` (`userid`);

--
-- Indexes for table `uss_options`
--
ALTER TABLE `uss_options`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uss_payment_methods`
--
ALTER TABLE `uss_payment_methods`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uss_transfers`
--
ALTER TABLE `uss_transfers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tx_ref` (`tx_ref`);

--
-- Indexes for table `uss_transfer_meta`
--
ALTER TABLE `uss_transfer_meta`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tx_ref` (`tx_ref`);

--
-- Indexes for table `uss_usermeta`
--
ALTER TABLE `uss_usermeta`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uss_users` (`_ref`);

--
-- Indexes for table `uss_users`
--
ALTER TABLE `uss_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `usercode` (`usercode`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `parent` (`parent`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `uss_beneficiaries`
--
ALTER TABLE `uss_beneficiaries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `uss_cards`
--
ALTER TABLE `uss_cards`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `uss_cheques`
--
ALTER TABLE `uss_cheques`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `uss_deposits`
--
ALTER TABLE `uss_deposits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `uss_exchanges`
--
ALTER TABLE `uss_exchanges`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `uss_loans`
--
ALTER TABLE `uss_loans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `uss_notifications`
--
ALTER TABLE `uss_notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `uss_options`
--
ALTER TABLE `uss_options`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `uss_payment_methods`
--
ALTER TABLE `uss_payment_methods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `uss_transfers`
--
ALTER TABLE `uss_transfers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT for table `uss_transfer_meta`
--
ALTER TABLE `uss_transfer_meta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- AUTO_INCREMENT for table `uss_usermeta`
--
ALTER TABLE `uss_usermeta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=121;

--
-- AUTO_INCREMENT for table `uss_users`
--
ALTER TABLE `uss_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

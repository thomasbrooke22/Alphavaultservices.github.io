<?php

$menu = new Menufy();

# Menu: Home
$menu->add('home', [
    "label" => 'Home',
    "href" => '/'
]);

# Menu: Contact
$menu->add('contact', [
    "label" => "Contact",
    "href" => "/contact"
]);

# Menu: Personal
$menu->add('personal', [
    "label" => "Personal Account",
    "href" => "/personal"
]);

# Menu: Corporate
$menu->add('corporate', [
    "label" => "Corporate Account",
    "href" => "/corporate"
]);




# set menu

self::$footerMenu = $menu;

<?php

$menu = new Menufy();

# Menu: Banking
$menu->add('banking', [ "label" => "Banking" ]);

    # Child: Service
    $menu->get('banking')->add("personal", [
        "label" => "personal banking",
        "href" => "/personal"
    ]);

    # Child: Service Details
    $menu->get('banking')->add('businesses', [
        "label" => "corporate banking",
        "href" => "/corporate"
    ]);

# Menu: Deposits
$menu->add('deposits', [
    'label' => "Deposits",
    "href" => "/deposits"
]);

# Menu: Credits
$menu->add('credits', [
    'label' => "Credits",
    "href" => "/credits"
]);


# Menu: Cards
$menu->add('cards', [
    'label' => "Cards",
    "href" => "/cards"
]);


# Menu: Investments
$menu->add('investments', [
    'label' => "Investments",
    "href" => "/investments"
]);


# Menu: Loans
$menu->add('loans', [
    'label' => "Loans",
    "href" => "/loans"
]);



# Menu: Insurance
$menu->add('insurance', [
    "label" => "Insurance",
    "href" => "/insurance"
]);


# Menu: Account
$menu->add('account', [ 'label' => 'Account' ]);

    # Child: Sign In
    $menu->get('account')->add('sign-in', [
        "label" => "sign in",
        "href" => UDASH_ROUTE
    ]);

    # Child: Sign Up
    $menu->get('account')->add('sign-up', [
        "label" => "sign up",
        "href" => UDASH_ROUTE . "/signup"
    ]);


####### [ set Menu ] #######

self::$menu = $menu;
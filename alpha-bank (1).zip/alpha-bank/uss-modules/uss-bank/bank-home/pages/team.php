

         <!-- team area start -->
         <section class="tp-team-breadcrumb-area pt-120 pb-70">
            <div class="container">
               <div class="row">
                  <div class="col-xl-3 col-lg-4 col-md-6">
                     <div class="tp-team-item p-relative mb-50 wow fadeInUp" data-wow-duration="1s" data-wow-delay=".3s">
                        <div class="tp-team-item-thumb">
                           <a href="team-details.html"><img src="%{:assets-dir}/img/team/img-1.jpg" alt=""></a>
                        </div>
                        <div class="tp-team-social">
                           <a class="icon-1" href="#"><i class="fa-brands fa-facebook-f"></i></a>
                           <a class="icon-2" href="#"><i class="fa-brands fa-twitter"></i></a>
                           <a class="icon-3" href="#"><i class="fa-brands fa-instagram"></i></a>
                           <a class="icon-4" href="#"><i class="fa-brands fa-pinterest"></i></a>
                        </div>
                        <div class="tp-team-info text-center">
                           <h4 class="tp-team-info-title"><a href="team-details.html">Albert Flores</a></h4>
                           <p>Designer</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-3 col-lg-4 col-md-6">
                     <div class="tp-team-item p-relative mb-50 wow fadeInUp" data-wow-duration="1s" data-wow-delay=".5s">
                        <div class="tp-team-item-thumb">
                           <a href="team-details.html"><img src="%{:assets-dir}/img/team/img-2.jpg" alt=""></a>
                        </div>
                        <div class="tp-team-social">
                           <a class="icon-1" href="#"><i class="fa-brands fa-facebook-f"></i></a>
                           <a class="icon-2" href="#"><i class="fa-brands fa-twitter"></i></a>
                           <a class="icon-3" href="#"><i class="fa-brands fa-instagram"></i></a>
                           <a class="icon-4" href="#"><i class="fa-brands fa-pinterest"></i></a>
                        </div>
                        <div class="tp-team-info text-center">
                           <h4 class="tp-team-info-title"><a href="team-details.html">Kathryn Murphy</a></h4>
                           <p>Designer</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-3 col-lg-4 col-md-6">
                     <div class="tp-team-item p-relative mb-50 wow fadeInUp" data-wow-duration="1s" data-wow-delay=".7s">
                        <div class="tp-team-item-thumb">
                           <a href="team-details.html"><img src="%{:assets-dir}/img/team/img-3.jpg" alt=""></a>
                        </div>
                        <div class="tp-team-social">
                           <a class="icon-1" href="#"><i class="fa-brands fa-facebook-f"></i></a>
                           <a class="icon-2" href="#"><i class="fa-brands fa-twitter"></i></a>
                           <a class="icon-3" href="#"><i class="fa-brands fa-instagram"></i></a>
                           <a class="icon-4" href="#"><i class="fa-brands fa-pinterest"></i></a>
                        </div>
                        <div class="tp-team-info text-center">
                           <h4 class="tp-team-info-title"><a href="team-details.html">Marvin McKinney</a></h4>
                           <p>Designer</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-3 col-lg-4 col-md-6">
                     <div class="tp-team-item p-relative mb-50 wow fadeInUp" data-wow-duration="1s" data-wow-delay=".9s">
                        <div class="tp-team-item-thumb">
                           <a href="team-details.html"><img src="%{:assets-dir}/img/team/img-4.jpg" alt=""></a>
                        </div>
                        <div class="tp-team-social">
                           <a class="icon-1" href="#"><i class="fa-brands fa-facebook-f"></i></a>
                           <a class="icon-2" href="#"><i class="fa-brands fa-twitter"></i></a>
                           <a class="icon-3" href="#"><i class="fa-brands fa-instagram"></i></a>
                           <a class="icon-4" href="#"><i class="fa-brands fa-pinterest"></i></a>
                        </div>
                        <div class="tp-team-info text-center">
                           <h4 class="tp-team-info-title"><a href="team-details.html">Leslie Alexander</a></h4>
                           <p>Designer</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-3 col-lg-4 col-md-6">
                     <div class="tp-team-item p-relative mb-50 wow fadeInUp" data-wow-duration="1s" data-wow-delay=".3s">
                        <div class="tp-team-item-thumb">
                           <a href="team-details.html"><img src="%{:assets-dir}/img/team/img-3.jpg" alt=""></a>
                        </div>
                        <div class="tp-team-social">
                           <a class="icon-1" href="#"><i class="fa-brands fa-facebook-f"></i></a>
                           <a class="icon-2" href="#"><i class="fa-brands fa-twitter"></i></a>
                           <a class="icon-3" href="#"><i class="fa-brands fa-instagram"></i></a>
                           <a class="icon-4" href="#"><i class="fa-brands fa-pinterest"></i></a>
                        </div>
                        <div class="tp-team-info text-center">
                           <h4 class="tp-team-info-title"><a href="team-details.html">Marvin McKinney</a></h4>
                           <p>Designer</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-3 col-lg-4 col-md-6">
                     <div class="tp-team-item p-relative mb-50 wow fadeInUp" data-wow-duration="1s" data-wow-delay=".5s">
                        <div class="tp-team-item-thumb">
                           <a href="team-details.html"><img src="%{:assets-dir}/img/team/img-4.jpg" alt=""></a>
                        </div>
                        <div class="tp-team-social">
                           <a class="icon-1" href="#"><i class="fa-brands fa-facebook-f"></i></a>
                           <a class="icon-2" href="#"><i class="fa-brands fa-twitter"></i></a>
                           <a class="icon-3" href="#"><i class="fa-brands fa-instagram"></i></a>
                           <a class="icon-4" href="#"><i class="fa-brands fa-pinterest"></i></a>
                        </div>
                        <div class="tp-team-info text-center">
                           <h4 class="tp-team-info-title"><a href="team-details.html">Leslie Alexander</a></h4>
                           <p>Designer</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-3 col-lg-4 col-md-6">
                     <div class="tp-team-item p-relative mb-50 wow fadeInUp" data-wow-duration="1s" data-wow-delay=".7s">
                        <div class="tp-team-item-thumb">
                           <a href="team-details.html"><img src="%{:assets-dir}/img/team/img-2.jpg" alt=""></a>
                        </div>
                        <div class="tp-team-social">
                           <a class="icon-1" href="#"><i class="fa-brands fa-facebook-f"></i></a>
                           <a class="icon-2" href="#"><i class="fa-brands fa-twitter"></i></a>
                           <a class="icon-3" href="#"><i class="fa-brands fa-instagram"></i></a>
                           <a class="icon-4" href="#"><i class="fa-brands fa-pinterest"></i></a>
                        </div>
                        <div class="tp-team-info text-center">
                           <h4 class="tp-team-info-title"><a href="team-details.html">Kathryn Murphy</a></h4>
                           <p>Designer</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-3 col-lg-4 col-md-6">
                     <div class="tp-team-item p-relative mb-50 wow fadeInUp" data-wow-duration="1s" data-wow-delay=".9s">
                        <div class="tp-team-item-thumb">
                           <a href="team-details.html"><img src="%{:assets-dir}/img/team/img-1.jpg" alt=""></a>
                        </div>
                        <div class="tp-team-social">
                           <a class="icon-1" href="#"><i class="fa-brands fa-facebook-f"></i></a>
                           <a class="icon-2" href="#"><i class="fa-brands fa-twitter"></i></a>
                           <a class="icon-3" href="#"><i class="fa-brands fa-instagram"></i></a>
                           <a class="icon-4" href="#"><i class="fa-brands fa-pinterest"></i></a>
                        </div>
                        <div class="tp-team-info text-center">
                           <h4 class="tp-team-info-title"><a href="team-details.html">Albert Flores</a></h4>
                           <p>Designer</p>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <!-- team area end -->


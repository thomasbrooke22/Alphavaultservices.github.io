

         <!-- project area start -->
         <section class="tp-project-area-3 pt-120 pb-120">
            <div class="container">
               <div class="row">
                  <div class="col-lg-12">
                     <div class="tp-project-details-thumb">
                        <img src="%{:assets-dir}/img/project/project-details/img-1.jpg" alt="">
                     </div>
                     <div class="tp-project-details-title-wrapper p-relative">
                        <h3 class="tp-project-details-title">We make small to large company</h3>
                        <p>Aliquam eros justo, posuere loborti vive rra laoreet matti ullamc orper posu ere viverra .Aliquam eros justo, posuere lobortis non, vive rra laoreet augue mattis fermentum ullamcorper viverra laoet Aliqam eros justo, posuere loborti viverra laoreet mat ullamcorper posue viverra .Aliquam eros justo, posere lobortis non, viverra laoreet augue mattis. Aliquam eros justo, posuere loborti viverra laoreet matti ullamcorper posuere viverra .Aliquam eros .</p>
                        <div class="tp-project-details-box d-flex">
                           <div class="tp-project-details-box-1">
                              <h4 class="tp-project-details-box-title">Customer:</h4>
                              <p>Hs robin</p>
                              <h4 class="tp-project-details-box-title">Location:</h4>
                              <p>Uk stand H.</p>
                              <h4 class="tp-project-details-box-title">Value</h4>
                              <p>150000  USD</p>
                           </div>
                           <div class="tp-project-details-box-2">
                              <h4 class="tp-project-details-box-title">Category</h4>
                              <p>Home making</p>
                              <h4 class="tp-project-details-box-title">Contact</h4>
                              <p>000-000-0001</p>
                              <h4 class="tp-project-details-box-title">Date</h4>
                              <p>Nov 19, 2023</p>
                           </div>
                        </div>
                     </div>
                     <div class="tp-project-details-subtitle-wrapper">
                        <h3 class="tp-project-details-subtitle">Project Challenging story</h3>
                        <p>Aliquam eros justo, posuere loborti vive rra laoreet matti ullamc orper posu ere viverra .Aliquamsto, posuere lobortis non, vive rra laoreet augue mattis fermentum ullamcorper viverra laoreet Aliquam eros justo, posuere loborti viverra laoreet mat ullamcorper posue viverra .Aliquam eros justo,</p>
                     </div>
                  </div>
               </div> 
               
               <div class="row">
                  <div class="col-lg-8">
                     <div class="tp-project-details-list">
                        <ul>
                           <li>
                              <span class="tp-project-details-list-title"><i class="fa-solid fa-check"></i> Best Emplementation</span>
                              <p>Oshed fact that a reader will be dist acted bioiiy design ished fact that a reader will.</p>
                           </li>
                           <li>
                              <span class="tp-project-details-list-title"><i class="fa-solid fa-check"></i> Design make for you</span>
                              <p>Oshed fact that a reader will be dist acted bioiiy design ished fact that a reader will.</p>
                           </li>
                           <li>
                              <span class="tp-project-details-list-title"><i class="fa-solid fa-check"></i> Finished the process</span>
                              <p>Oshed fact that a reader will be dist acted bioiiy design ished fact that a reader will.</p>
                           </li>
                           <li>
                              <span class="tp-project-details-list-title"><i class="fa-solid fa-check"></i> Follow Stretegy</span>
                              <p>Oshed fact that a reader will be dist acted bioiiy design ished fact that a reader will.</p>
                           </li>
                        </ul>
                     </div>
                  </div>
                  <div class="col-lg-4">
                     <div class="tp-project-details-list-thumb">
                        <img src="%{:assets-dir}/img/project/project-details/img-2.jpg" alt="">
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <!-- project area end -->


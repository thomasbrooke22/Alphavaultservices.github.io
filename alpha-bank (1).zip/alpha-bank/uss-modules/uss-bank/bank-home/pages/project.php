
         <!-- project area start -->
         <section class="tp-project-area-3 pt-120 pb-80">
            <div class="container">
               <div class="row">
                  <div class="col-lg-12">
                     <div class="tp-project-tab-wrapper d-flex justify-content-center">
                        <ul class="nav nav-pills mb-60 wow fadeInUp" data-wow-duration="1s" data-wow-delay=".3s" id="pills-tab" role="tablist">
                           <li class="nav-item" role="presentation">
                           <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">All Project</button>
                           </li>
                           <li class="nav-item" role="presentation">
                           <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-Architecher" type="button" role="tab" aria-controls="pills-Architecher" aria-selected="false">Architecher</button>
                           </li>
                           <li class="nav-item" role="presentation">
                           <button class="nav-link" id="pills-Large-tab" data-bs-toggle="pill" data-bs-target="#pills-Large" type="button" role="tab" aria-controls="pills-Large" aria-selected="false">Large</button>
                           </li>
                           <li class="nav-item" role="presentation">
                           <button class="nav-link" id="pills-Interiour-tab" data-bs-toggle="pill" data-bs-target="#pills-Interiour" type="button" role="tab" aria-controls="pills-Interiour" aria-selected="false">Interiour</button>
                           </li>
                           <li class="nav-item" role="presentation">
                           <button class="nav-link" id="pills-House-tab" data-bs-toggle="pill" data-bs-target="#pills-House" type="button" role="tab" aria-controls="pills-House" aria-selected="false">House</button>
                           </li>
                        </ul>
                     </div>
                     <div class="tab-content" id="pills-tabContent">
                        <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                           <div class="row"> 
                              <div class="col-lg-4 col-md-6">
                                 <div class="tp-project-item-3 text-center mb-40">
                                    <div class="tp-project-thumb-3">
                                       <a href="project-details.html"><img src="%{:assets-dir}/img/project/home-3/img-1.jpg" alt=""></a>
                                    </div>
                                    <div class="tp-project-content-3">
                                       <span>New product unlocked</span>
                                       <h3 class="tp-project-title-3"><a href="project-details.html">Budget Buddy</a></h3>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-4 col-md-6">
                                 <div class="tp-project-item-3 text-center mb-40">
                                    <div class="tp-project-thumb-3">
                                       <a href="project-details.html"><img src="%{:assets-dir}/img/project/home-3/img-2.jpg" alt=""></a>
                                    </div>
                                    <div class="tp-project-content-3">
                                       <span>Artificial Intelligent</span>
                                       <h3 class="tp-project-title-3"><a href="project-details.html">Automotive System</a></h3>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-4 col-md-6">
                                 <div class="tp-project-item-3 text-center mb-40">
                                    <div class="tp-project-thumb-3">
                                       <a href="project-details.html"><img src="%{:assets-dir}/img/project/home-3/img-3.jpg" alt=""></a>
                                    </div>
                                    <div class="tp-project-content-3">
                                       <span>Set your goals for</span>
                                       <h3 class="tp-project-title-3"><a href="project-details.html">Smart Savings</a></h3>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-4 col-md-6">
                                 <div class="tp-project-item-3 text-center mb-40">
                                    <div class="tp-project-thumb-3">
                                       <a href="project-details.html"><img src="%{:assets-dir}/img/project/home-3/img-4.jpg" alt=""></a>
                                    </div>
                                    <div class="tp-project-content-3">
                                       <span>New product unlocked</span>
                                       <h3 class="tp-project-title-3"><a href="project-details.html">Pure Consulting</a></h3>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-4 col-md-6">
                                 <div class="tp-project-item-3 text-center mb-40">
                                    <div class="tp-project-thumb-3">
                                       <a href="project-details.html"><img src="%{:assets-dir}/img/project/home-3/img-5.jpg" alt=""></a>
                                    </div>
                                    <div class="tp-project-content-3">
                                       <span>Artificial Intelligent</span>
                                       <h3 class="tp-project-title-3"><a href="project-details.html">Data Analysis</a></h3>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-4 col-md-6">
                                 <div class="tp-project-item-3 text-center mb-40">
                                    <div class="tp-project-thumb-3">
                                       <a href="project-details.html"><img src="%{:assets-dir}/img/project/home-3/img-6.jpg" alt=""></a>
                                    </div>
                                    <div class="tp-project-content-3">
                                       <span>Set your goals for</span>
                                       <h3 class="tp-project-title-3"><a href="project-details.html">Market Rules</a></h3>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="tab-pane fade" id="pills-Architecher" role="tabpanel" aria-labelledby="pills-Architecher-tab">
                           <div class="row"> 
                              <div class="col-lg-4 col-md-6">
                                 <div class="tp-project-item-3 text-center mb-40">
                                    <div class="tp-project-thumb-3">
                                       <a href="project-details.html"><img src="%{:assets-dir}/img/project/home-3/img-7.jpg" alt=""></a>
                                    </div>
                                    <div class="tp-project-content-3">
                                       <span>New product unlocked</span>
                                       <h3 class="tp-project-title-3"><a href="project-details.html">Budget Buddy</a></h3>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-4 col-md-6">
                                 <div class="tp-project-item-3 text-center mb-40">
                                    <div class="tp-project-thumb-3">
                                       <a href="project-details.html"><img src="%{:assets-dir}/img/project/home-3/img-8.jpg" alt=""></a>
                                    </div>
                                    <div class="tp-project-content-3">
                                       <span>Artificial Intelligent</span>
                                       <h3 class="tp-project-title-3"><a href="project-details.html">Automotive System</a></h3>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-4 col-md-6">
                                 <div class="tp-project-item-3 text-center mb-40">
                                    <div class="tp-project-thumb-3">
                                       <a href="project-details.html"><img src="%{:assets-dir}/img/project/home-3/img-9.jpg" alt=""></a>
                                    </div>
                                    <div class="tp-project-content-3">
                                       <span>Set your goals for</span>
                                       <h3 class="tp-project-title-3"><a href="project-details.html">Smart Savings</a></h3>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-4 col-md-6">
                                 <div class="tp-project-item-3 text-center mb-40">
                                    <div class="tp-project-thumb-3">
                                       <a href="project-details.html"><img src="%{:assets-dir}/img/project/home-3/img-10.jpg" alt=""></a>
                                    </div>
                                    <div class="tp-project-content-3">
                                       <span>New product unlocked</span>
                                       <h3 class="tp-project-title-3"><a href="project-details.html">Pure Consulting</a></h3>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-4 col-md-6">
                                 <div class="tp-project-item-3 text-center mb-40">
                                    <div class="tp-project-thumb-3">
                                       <a href="project-details.html"><img src="%{:assets-dir}/img/project/home-3/img-11.jpg" alt=""></a>
                                    </div>
                                    <div class="tp-project-content-3">
                                       <span>Artificial Intelligent</span>
                                       <h3 class="tp-project-title-3"><a href="project-details.html">Data Analysis</a></h3>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-4 col-md-6">
                                 <div class="tp-project-item-3 text-center mb-40">
                                    <div class="tp-project-thumb-3">
                                       <a href="project-details.html"><img src="%{:assets-dir}/img/project/home-3/img-12.jpg" alt=""></a>
                                    </div>
                                    <div class="tp-project-content-3">
                                       <span>Set your goals for</span>
                                       <h3 class="tp-project-title-3"><a href="project-details.html">Market Rules</a></h3>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="tab-pane fade" id="pills-Large" role="tabpanel" aria-labelledby="pills-Large-tab">
                           <div class="row"> 
                              <div class="col-lg-4 col-md-6">
                                 <div class="tp-project-item-3 text-center mb-40">
                                    <div class="tp-project-thumb-3">
                                       <a href="project-details.html"><img src="%{:assets-dir}/img/project/home-3/img-13.jpg" alt=""></a>
                                    </div>
                                    <div class="tp-project-content-3">
                                       <span>New product unlocked</span>
                                       <h3 class="tp-project-title-3"><a href="project-details.html">Budget Buddy</a></h3>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-4 col-md-6">
                                 <div class="tp-project-item-3 text-center mb-40">
                                    <div class="tp-project-thumb-3">
                                       <a href="project-details.html"><img src="%{:assets-dir}/img/project/home-3/img-12.jpg" alt=""></a>
                                    </div>
                                    <div class="tp-project-content-3">
                                       <span>Artificial Intelligent</span>
                                       <h3 class="tp-project-title-3"><a href="project-details.html">Automotive System</a></h3>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-4 col-md-6">
                                 <div class="tp-project-item-3 text-center mb-40">
                                    <div class="tp-project-thumb-3">
                                       <a href="project-details.html"><img src="%{:assets-dir}/img/project/home-3/img-10.jpg" alt=""></a>
                                    </div>
                                    <div class="tp-project-content-3">
                                       <span>Set your goals for</span>
                                       <h3 class="tp-project-title-3"><a href="project-details.html">Smart Savings</a></h3>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-4 col-md-6">
                                 <div class="tp-project-item-3 text-center mb-40">
                                    <div class="tp-project-thumb-3">
                                       <a href="project-details.html"><img src="%{:assets-dir}/img/project/home-3/img-5.jpg" alt=""></a>
                                    </div>
                                    <div class="tp-project-content-3">
                                       <span>New product unlocked</span>
                                       <h3 class="tp-project-title-3"><a href="project-details.html">Pure Consulting</a></h3>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-4 col-md-6">
                                 <div class="tp-project-item-3 text-center mb-40">
                                    <div class="tp-project-thumb-3">
                                       <a href="project-details.html"><img src="%{:assets-dir}/img/project/home-3/img-6.jpg" alt=""></a>
                                    </div>
                                    <div class="tp-project-content-3">
                                       <span>Artificial Intelligent</span>
                                       <h3 class="tp-project-title-3"><a href="project-details.html">Data Analysis</a></h3>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-4 col-md-6">
                                 <div class="tp-project-item-3 text-center mb-40">
                                    <div class="tp-project-thumb-3">
                                       <a href="project-details.html"><img src="%{:assets-dir}/img/project/home-3/img-8.jpg" alt=""></a>
                                    </div>
                                    <div class="tp-project-content-3">
                                       <span>Set your goals for</span>
                                       <h3 class="tp-project-title-3"><a href="project-details.html">Market Rules</a></h3>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="tab-pane fade" id="pills-Interiour" role="tabpanel" aria-labelledby="pills-Interiour-tab">
                           <div class="row"> 
                              <div class="col-lg-4 col-md-6">
                                 <div class="tp-project-item-3 text-center mb-40">
                                    <div class="tp-project-thumb-3">
                                       <a href="project-details.html"><img src="%{:assets-dir}/img/project/home-3/img-6.jpg" alt=""></a>
                                    </div>
                                    <div class="tp-project-content-3">
                                       <span>New product unlocked</span>
                                       <h3 class="tp-project-title-3"><a href="project-details.html">Budget Buddy</a></h3>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-4 col-md-6">
                                 <div class="tp-project-item-3 text-center mb-40">
                                    <div class="tp-project-thumb-3">
                                       <a href="project-details.html"><img src="%{:assets-dir}/img/project/home-3/img-3.jpg" alt=""></a>
                                    </div>
                                    <div class="tp-project-content-3">
                                       <span>Artificial Intelligent</span>
                                       <h3 class="tp-project-title-3"><a href="project-details.html">Automotive System</a></h3>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-4 col-md-6">
                                 <div class="tp-project-item-3 text-center mb-40">
                                    <div class="tp-project-thumb-3">
                                       <a href="project-details.html"><img src="%{:assets-dir}/img/project/home-3/img-1.jpg" alt=""></a>
                                    </div>
                                    <div class="tp-project-content-3">
                                       <span>Set your goals for</span>
                                       <h3 class="tp-project-title-3"><a href="project-details.html">Smart Savings</a></h3>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-4 col-md-6">
                                 <div class="tp-project-item-3 text-center mb-40">
                                    <div class="tp-project-thumb-3">
                                       <a href="project-details.html"><img src="%{:assets-dir}/img/project/home-3/img-8.jpg" alt=""></a>
                                    </div>
                                    <div class="tp-project-content-3">
                                       <span>New product unlocked</span>
                                       <h3 class="tp-project-title-3"><a href="project-details.html">Pure Consulting</a></h3>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-4 col-md-6">
                                 <div class="tp-project-item-3 text-center mb-40">
                                    <div class="tp-project-thumb-3">
                                       <a href="project-details.html"><img src="%{:assets-dir}/img/project/home-3/img-9.jpg" alt=""></a>
                                    </div>
                                    <div class="tp-project-content-3">
                                       <span>Artificial Intelligent</span>
                                       <h3 class="tp-project-title-3"><a href="project-details.html">Data Analysis</a></h3>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-4 col-md-6">
                                 <div class="tp-project-item-3 text-center mb-40">
                                    <div class="tp-project-thumb-3">
                                       <a href="project-details.html"><img src="%{:assets-dir}/img/project/home-3/img-10.jpg" alt=""></a>
                                    </div>
                                    <div class="tp-project-content-3">
                                       <span>Set your goals for</span>
                                       <h3 class="tp-project-title-3"><a href="project-details.html">Market Rules</a></h3>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="tab-pane fade" id="pills-House" role="tabpanel" aria-labelledby="pills-House-tab">
                           <div class="row"> 
                              <div class="col-lg-4 col-md-6">
                                 <div class="tp-project-item-3 text-center mb-40">
                                    <div class="tp-project-thumb-3">
                                       <a href="project-details.html"><img src="%{:assets-dir}/img/project/home-3/img-12.jpg" alt=""></a>
                                    </div>
                                    <div class="tp-project-content-3">
                                       <span>New product unlocked</span>
                                       <h3 class="tp-project-title-3"><a href="project-details.html">Budget Buddy</a></h3>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-4 col-md-6">
                                 <div class="tp-project-item-3 text-center mb-40">
                                    <div class="tp-project-thumb-3">
                                       <a href="project-details.html"><img src="%{:assets-dir}/img/project/home-3/img-13.jpg" alt=""></a>
                                    </div>
                                    <div class="tp-project-content-3">
                                       <span>Artificial Intelligent</span>
                                       <h3 class="tp-project-title-3"><a href="project-details.html">Automotive System</a></h3>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-4 col-md-6">
                                 <div class="tp-project-item-3 text-center mb-40">
                                    <div class="tp-project-thumb-3">
                                       <a href="project-details.html"><img src="%{:assets-dir}/img/project/home-3/img-11.jpg" alt=""></a>
                                    </div>
                                    <div class="tp-project-content-3">
                                       <span>Set your goals for</span>
                                       <h3 class="tp-project-title-3"><a href="project-details.html">Smart Savings</a></h3>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-4 col-md-6">
                                 <div class="tp-project-item-3 text-center mb-40">
                                    <div class="tp-project-thumb-3">
                                       <a href="project-details.html"><img src="%{:assets-dir}/img/project/home-3/img-10.jpg" alt=""></a>
                                    </div>
                                    <div class="tp-project-content-3">
                                       <span>New product unlocked</span>
                                       <h3 class="tp-project-title-3"><a href="project-details.html">Pure Consulting</a></h3>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-4 col-md-6">
                                 <div class="tp-project-item-3 text-center mb-40">
                                    <div class="tp-project-thumb-3">
                                       <a href="project-details.html"><img src="%{:assets-dir}/img/project/home-3/img-6.jpg" alt=""></a>
                                    </div>
                                    <div class="tp-project-content-3">
                                       <span>Artificial Intelligent</span>
                                       <h3 class="tp-project-title-3"><a href="project-details.html">Data Analysis</a></h3>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-4 col-md-6">
                                 <div class="tp-project-item-3 text-center mb-40">
                                    <div class="tp-project-thumb-3">
                                       <a href="project-details.html"><img src="%{:assets-dir}/img/project/home-3/img-4.jpg" alt=""></a>
                                    </div>
                                    <div class="tp-project-content-3">
                                       <span>Set your goals for</span>
                                       <h3 class="tp-project-title-3"><a href="project-details.html">Market Rules</a></h3>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div> 
            </div>
         </section>
         <!-- project area end -->



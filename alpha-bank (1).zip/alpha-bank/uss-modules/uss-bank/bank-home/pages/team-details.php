

         <!-- team-details area start -->
         <section class="tp-team-details-breadcrumb-area pt-120 pb-90">
            <div class="container">
               <div class="row">
                  <div class="col-lg-5">
                     <div class="tp-team-details-thumb mb-85">
                        <img src="%{:assets-dir}/img/team/breadcrumb-img.jpg" alt="">
                     </div>
                  </div>
                  <div class="col-lg-7">
                     <div class="tp-team-details-wrapper mb-85">
                        <h3 class="tp-team-details-name">Albert Flores</h3>
                        <span class="tp-team-details-description">Human Resource</span>
                        <p>sed ut perspiciatis unde omnis iste natus error sit voluptatem <br> accusantium doloremque laudantium, totam rem aperiam</p>
                        <div class="tp-team-details-information">
                           <h4>
                              <span>Phone :</span> <a href="tel:5550115">(319) 555-0115</a>
                           </h4>
                           <h4>
                              <span>Email :</span> <a href="https://template.wphix.com/cdn-cgi/l/email-protection#d1b5b4b3a3b0ffb9bebda591b4a9b0bca1bdb4ffb2bebc"><span class="__cf_email__" data-cfemail="bdd9d8dfcfdc93d5d2d1c9fdd8c5dcd0cdd1d893ded2d0">%{@email:admin}</span></a>
                           </h4>
                           <h4>
                              <span>Website :</span> <a href="https://template.wphix.com/cdn-cgi/l/email-protection#eb8f8e89998ac58384879fab8e938a869b878ec5888486">http://yoursite.com/themepure</a>
                           </h4>
                           <h4>
                              <span>Address :</span> <a href="https://www.google.com/maps">6391 Elgin St. Celina, Delaware 10299</a>
                           </h4>
                        </div>
                        <div class="tp-team-details-social">
                           <a href="#"><i class="fab fa-facebook-f"></i></a>
                           <a href="#"><i class="fab fa-twitter"></i></a>
                           <a href="#"><i class="fa-brands fa-google-plus-g"></i></a>
                           <a href="#"><i class="fa-brands fa-instagram"></i></a>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="row">
                  <div class="col-lg-8 col-md-12">
                     <div class="tp-team-details-skills fix">
                        <h3 class="tp-team-details-title">Others Skills</h3>
                        <p>Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's in the <br> ou standard dummy text ever since the 1500s, when an unknown printer took</p>
                        <div class="tp-team-details-skills-progress">
                           <div class="tp-team-details-progress-item">
                              <div class="tp-team-details-progress-title p-relative">
                                 <h5>Energy <span class="pursent-1 wow slideInLeft" data-wow-duration=".8s" data-wow-delay=".3s">90%</span></h5>
                              </div>
                              <div class="progress">
                                 <div class="progress-bar wow slideInLeft" data-wow-duration=".8s" data-wow-delay=".3s" role="progressbar" data-width="90%" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100"></div>
                              </div>
                           </div>
                           <div class="tp-team-details-progress-item">
                              <div class="tp-team-details-progress-title p-relative">
                                 <h5>Tecnical <span class="pursent-2 wow slideInLeft" data-wow-duration=".8s" data-wow-delay=".3s">95%</span></h5>
                              </div>
                              <div class="progress">
                                 <div class="progress-bar wow slideInLeft" data-wow-duration=".8s" data-wow-delay=".3s" role="progressbar" data-width="95%" aria-valuenow="95" aria-valuemin="0" aria-valuemax="100"></div>
                              </div>
                           </div>
                           <div class="tp-team-details-progress-item">
                              <div class="tp-team-details-progress-title p-relative">
                                 <h5>Clients Satisfaction <span class="pursent-3 wow slideInLeft" data-wow-duration=".8s" data-wow-delay=".3s">85%</span></h5>
                              </div>
                              <div class="progress">
                                 <div class="progress-bar wow slideInLeft" data-wow-duration=".8s" data-wow-delay=".3s" role="progressbar" data-width="85%" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100"></div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-4 col-md-12">
                     <div class="tp-team-details-value">
                        <h3 class="tp-team-details-title">Others Value</h3>
                        <ul>
                           <li><i class="fa-solid fa-check"></i> Mistakes To Avoid to the dummy</li>
                           <li><i class="fa-solid fa-check"></i> Your Startup industry standard loream saum.</li>
                           <li><i class="fa-solid fa-check"></i> Knew About Fonts text the printing and </li>
                           <li><i class="fa-solid fa-check"></i> Mistakes To Avoid to the dummy printing </li>
                        </ul>
                        <p>Ipsum is simply dummy text of the printing and type setting industry. Lorem Ipsum has been the industry's in the abouti standard dummy</p>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <!-- team-details area end -->


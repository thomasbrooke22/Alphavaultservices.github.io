

         <!-- about area start -->
         <section class="tp-about-area p-relative pt-130 pb-210">
            <div class="tp-about-shape">
               <img src="%{:assets-dir}/img/about/shape-3.png" alt="">
            </div>
            <div class="container">
               <div class="row">
                  <div class="col-lg-6">
                     <div class="tp-about-thumb-wrapper p-relative wow fadeInLeft" data-wow-duration="1s" data-wow-delay=".3s">
                        <div class="main">
                           <img src="%{:assets-dir}/img/about/img-1.jpg" alt="">
                        </div>
                        <img class="shape-1" src="%{:assets-dir}/img/about/img-2.jpg" alt="">
                        <img class="shape-2" src="%{:assets-dir}/img/about/shape-1.png" alt="">
                        <img class="shape-3" src="%{:assets-dir}/img/about/shape-2.png" alt="">
                        <img class="shape-4" src="%{:assets-dir}/img/about/shape-4.png" alt="">
                     </div>
                  </div>
                  <div class="col-lg-6">
                     <div class="tp-about-wrapper">
                        <div class="tp-about-title-wrapper">
                           <span class="tp-section-title-pre">ABOUT US</span>
                           <h3 class="tp-section-title">Solutions that make a difference</h3>
                        </div>
                        <p>Payment solutions enable businesses to accept payments Payment stions enable businesses to accept payments from ctly customers ctly securely. stions enable businesses to accept payments from ctly customers ctly securely.</p>
                        <div class="tp-about-wrapper-list">
                           <ul>
                              <li><span><i class="fa-regular fa-circle"></i></span> Mistakes To Avoid to dum Auam.</li>
                              <li><span><i class="fa-regular fa-circle"></i></span> Avoid to the dumy mistakes</li>
                              <li><span><i class="fa-regular fa-circle"></i></span> Your Startup industry stan</li>
                              <li><span><i class="fa-regular fa-circle"></i></span> Our Startup industry Here</li>
                           </ul>
                        </div>
                        <div class="tp-about-btn">
                           <a class="tp-btn" href="about.html">About Us <span><i class="fa-regular fa-plus"></i></span></a>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <!-- about area end -->


         
         <!-- faq area start -->
         <section class="tp-faq-area p-relative pt-120 pb-120" data-background="%{:assets-dir}/img/faq/bg-shape.png">
            <div class="tp-faq-bg"></div>
            <div class="container">
               <div class="row">
                  <div class="col-lg-5">
                     <div class="tp-faq-wrapper">
                        <div class="tp-faq-title-wrapper">
                           <span class="tp-section-title-pre">ask anything</span>
                           <h3 class="tp-section-title">You can contact <br> us for any question </h3>
                           <p>Fact that a reader will be distrol acted bioiiy desig the.ished fact that a reader will be distrol acted bioiiy bioiiy desig the.ished fact that a reader ished fact that </p>
                        </div>
                        <div class="tp-faq-counter-wrapper d-flex">
                           <div class="tp-faq-counter d-flex align-items-center mr-20 mb-30">
                              <div class="tp-faq-counter-icon">
                                 <span>
                                    <img src="%{:assets-dir}/img/faq/icon-1.svg" alt="">
                                 </span>
                              </div>
                              <div class="tp-faq-counter-content">
                                 <h4 class="tp-faq-counter-title"><span class="purecounter" data-purecounter-duration="3" data-purecounter-end="10"></span>+</h4>
                                 <p>Experiences</p>
                              </div>
                           </div>
                           <div class="tp-faq-counter d-flex align-items-center mb-30">
                              <div class="tp-faq-counter-icon">
                                 <span>
                                    <img src="%{:assets-dir}/img/faq/icon-2.svg" alt="">
                                 </span>
                              </div>
                              <div class="tp-faq-counter-content">
                                 <h4 class="tp-faq-counter-title"><span class="purecounter" data-purecounter-duration="2" data-purecounter-end="500"></span>+</h4>
                                 <p>Happy Client</p>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-7">
                     <div class="tp-faq-tab-content tp-accordion wow fadeInRight" data-wow-duration="1s" data-wow-delay=".3s">
                        <div class="accordion" id="general_accordion">
                           <div class="accordion-item tp-faq-active">
                              <h2 class="accordion-header" id="headingOne">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                 What is business consulting?
                                </button>
                              </h2>
                              <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#general_accordion">
                                <div class="accordion-body">
                                  <p>Business consulting is a service provided by professionals who offer expert advice and guidance to organizations seeking to improve their business processes, strategies, and operations</p>
                                </div>
                              </div>
                            </div>
                           <div class="accordion-item">
                             <h2 class="accordion-header" id="headingTwo">
                               <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                 What types of businesses typically use consulting services?
                               </button>
                             </h2>
                             <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#general_accordion">
                               <div class="accordion-body">
                                 <p>Business consulting is a service provided by professionals who offer expert advice and guidance to organizations seeking to improve their business processes, strategies, and operations</p>
                               </div>
                             </div>
                           </div>
                           <div class="accordion-item">
                             <h2 class="accordion-header" id="headingThree">
                               <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                 What are the benefits of using a business consulting service?
                               </button>
                             </h2>
                             <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#general_accordion">
                               <div class="accordion-body">
                                 <p>Business consulting is a service provided by professionals who offer expert advice and guidance to organizations seeking to improve their business processes, strategies, and operations</p>
                               </div>
                             </div>
                           </div>
                           <div class="accordion-item">
                             <h2 class="accordion-header" id="headingFour">
                               <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                 How much do consulting services cost?
                               </button>
                             </h2>
                             <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#general_accordion">
                               <div class="accordion-body">
                                 <p>Business consulting is a service provided by professionals who offer expert advice and guidance to organizations seeking to improve their business processes, strategies, and operations</p>
                               </div>
                             </div>
                           </div>
                         </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <!-- faq area end -->


         
         <!-- process area start -->
         <section class="tp-process-arae pt-120 pb-120" data-bg-color="#F6F6F9">
            <div class="container">
               <div class="row">
                  <div class="col-lg-6">
                     <div class="tp-process-wrapper">
                        <div class="tp-process-title mb-40">
                           <span class="tp-section-title-pre">Our work process</span>
                           <h3 class="tp-section-title">Strategy is the key to <br> success</h3>
                        </div>
                        <div class="tp-process-item d-flex align-items-center">
                           <div class="tp-process-item-icon">
                              <span>
                                 <img src="%{:assets-dir}/img/process/icon-1.svg" alt="">
                              </span>
                           </div>
                           <div class="tp-process-item-content">
                              <h4 class="tp-process-item-title">Best emplementation</h4>
                              <p>Ished fact that a reader will be distrol acted bioiiy desig the.ished fact that a reader will be distrol acted bioiiy bioiiy desig the.ished fact that a reader.</p>
                           </div>
                        </div>
                        <div class="tp-process-item d-flex align-items-center">
                           <div class="tp-process-item-icon">
                              <span>
                                 <img src="%{:assets-dir}/img/process/icon-2.svg" alt="">
                              </span>
                           </div>
                           <div class="tp-process-item-content">
                              <h4 class="tp-process-item-title">Design make for you</h4>
                              <p>Ished fact that a reader will be distrol acted bioiiy desig the.ished fact that a reader will be distrol acted bioiiy bioiiy desig the.ished fact that a reader.</p>
                           </div>
                        </div>
                        <div class="tp-process-item d-flex align-items-center">
                           <div class="tp-process-item-icon">
                              <span>
                                 <img src="%{:assets-dir}/img/process/icon-3.svg" alt="">
                              </span>
                           </div>
                           <div class="tp-process-item-content">
                              <h4 class="tp-process-item-title">Finished the process</h4>
                              <p>Ished fact that a reader will be distrol acted bioiiy desig the.ished fact that a reader will be distrol acted bioiiy bioiiy desig the.ished fact that a reader.</p>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-6">
                     <div class="tp-process-thumb-wrapper p-relative wow fadeInRight" data-wow-duration="1s" data-wow-delay=".3s">
                        <div class="tp-process-thumb p-relative">
                           <div class="main">
                              <img src="%{:assets-dir}/img/process/img-1.jpg" alt="">
                           </div>
                           <img class="shape-1" src="%{:assets-dir}/img/process/img-2.jpg" alt="">
                        </div>
                        <div class="tp-process-counter d-flex align-items-center">
                           <div class="tp-process-counter-icon">
                              <span>
                                 <i class="flaticon-030-machine-repair"></i>
                              </span>
                           </div>
                           <div class="tp-process-content">
                              <h4 class="tp-process-counter-title"><span class="purecounter" data-purecounter-duration="3" data-purecounter-end="10"></span>k+</h4>
                              <p>Project Complete</p>
                           </div>
                        </div>
                        <div class="tp-process-trusted text-center">
                           <p>Trusted By <br> <span>2345</span></p>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <!-- process area end -->



         <!-- testimonial area start -->
         <section class="tp-testimonial-area tp-testimonial-bg-color p-relative pt-80 pb-50" data-bg-color="#F6F6F9">
            <div class="tp-testimonial-bg">
               <img src="%{:assets-dir}/img/testimonial/bg-shape.png" alt="">
            </div>
            <div class="container">
               <div class="row">
                  <div class="col-lg-12">
                     <div class="tp-testimonial-title">
                        <span class="tp-section-title-pre">Clients Testomonial</span>
                        <h3 class="tp-section-title">Unleashing the power of <br> your business</h3>
                     </div>
                  </div>
                  <div class="tp-testimonial-active swiper-container">
                     <div class="swiper-wrapper mb-30 mt-20">
                        <div class="swiper-slide">
                           <div class="tp-testimonial-item-wrapper d-flex align-items-center">
                              <div class="tp-testimonial-item-thumb">
                                 <img src="%{:assets-dir}/img/testimonial/img-1.jpg" alt="">
                              </div>
                              <div class="tp-testimonial-item-content p-relative">
                                 <div class="tp-testimonial-item-rating">
                                    <span class="color"><i class="fa-solid fa-star"></i></span>
                                    <span class="color"><i class="fa-solid fa-star"></i></span>
                                    <span class="color"><i class="fa-solid fa-star"></i></span>
                                    <span><i class="fa-solid fa-star"></i></span>
                                    <span><i class="fa-solid fa-star"></i></span>
                                 </div>
                                 <p>Don't just take our word for it hear what our customers have to say about us! we have helped thousand people Don't just take our </p>
                                 <h4 class="tp-testimonial-item-title">Hardli sefa</h4>
                                 <span>Customer</span>
                                 <div class="tp-testimonial-item-quot">
                                    <img src="%{:assets-dir}/img/testimonial/quot.png" alt="">
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="swiper-slide">
                           <div class="tp-testimonial-item-wrapper d-flex align-items-center">
                              <div class="tp-testimonial-item-thumb">
                                 <img src="%{:assets-dir}/img/testimonial/img-2.jpg" alt="">
                              </div>
                              <div class="tp-testimonial-item-content p-relative">
                                 <div class="tp-testimonial-item-rating">
                                    <span class="color"><i class="fa-solid fa-star"></i></span>
                                    <span class="color"><i class="fa-solid fa-star"></i></span>
                                    <span class="color"><i class="fa-solid fa-star"></i></span>
                                    <span><i class="fa-solid fa-star"></i></span>
                                    <span><i class="fa-solid fa-star"></i></span>
                                 </div>
                                 <p>Don't just take our word for it hear what our customers have to say about us! we have helped thousand people Don't just take our </p>
                                 <h4 class="tp-testimonial-item-title">Sahanaz sakil</h4>
                                 <span>Customer</span>
                                 <div class="tp-testimonial-item-quot">
                                    <img src="%{:assets-dir}/img/testimonial/quot.png" alt="">
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="tp-testimonial-nav text-end">
                     <button type="button" class="testimonial-button-prev-1"><i class="fa-regular fa-arrow-left"></i>
                     </button>
                     <button type="button" class="testimonial-button-next-1"><i class="fa-regular fa-arrow-right"></i>
                     </button>
                  </div>
               </div>
            </div>
         </section>
         <!-- testimonial area end -->



         <!-- team area start -->
         <section class="tp-team-area pt-120 pb-120 tp-team-item-margin">
            <div class="container">
               <div class="row">
                  <div class="col-lg-12">
                     <div class="tp-team-title-wrapper text-center mb-30"> 
                        <span class="tp-section-title-pre">our team </span>
                        <h3 class="tp-section-title">Leading the way in business <br> transformation</h3>
                     </div>
                  </div>
               </div>
               <div class="row">
                  <div class="col-lg-3 col-md-6">
                     <div class="tp-team-item p-relative wow fadeInUp" data-wow-duration="1s" data-wow-delay=".3s">
                        <div class="tp-team-item-thumb">
                           <a href="team-details.html"><img src="%{:assets-dir}/img/team/img-1.jpg" alt=""></a>
                        </div>
                        <div class="tp-team-social">
                           <a class="icon-1" href="#"><i class="fa-brands fa-facebook-f"></i></a>
                           <a class="icon-2" href="#"><i class="fa-brands fa-twitter"></i></a>
                           <a class="icon-3" href="#"><i class="fa-brands fa-instagram"></i></a>
                           <a class="icon-4" href="#"><i class="fa-brands fa-pinterest"></i></a>
                        </div>
                        <div class="tp-team-info text-center">
                           <h4 class="tp-team-info-title"><a href="team-details.html">Albert Flores</a></h4>
                           <p>Designer</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-3 col-md-6">
                     <div class="tp-team-item p-relative wow fadeInUp" data-wow-duration="1s" data-wow-delay=".5s">
                        <div class="tp-team-item-thumb">
                           <a href="team-details.html"><img src="%{:assets-dir}/img/team/img-2.jpg" alt=""></a>
                        </div>
                        <div class="tp-team-social">
                           <a class="icon-1" href="#"><i class="fa-brands fa-facebook-f"></i></a>
                           <a class="icon-2" href="#"><i class="fa-brands fa-twitter"></i></a>
                           <a class="icon-3" href="#"><i class="fa-brands fa-instagram"></i></a>
                           <a class="icon-4" href="#"><i class="fa-brands fa-pinterest"></i></a>
                        </div>
                        <div class="tp-team-info text-center">
                           <h4 class="tp-team-info-title"><a href="team-details.html">Kathryn Murphy</a></h4>
                           <p>Designer</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-3 col-md-6">
                     <div class="tp-team-item p-relative wow fadeInUp" data-wow-duration="1s" data-wow-delay=".7s">
                        <div class="tp-team-item-thumb">
                           <a href="team-details.html"><img src="%{:assets-dir}/img/team/img-3.jpg" alt=""></a>
                        </div>
                        <div class="tp-team-social">
                           <a class="icon-1" href="#"><i class="fa-brands fa-facebook-f"></i></a>
                           <a class="icon-2" href="#"><i class="fa-brands fa-twitter"></i></a>
                           <a class="icon-3" href="#"><i class="fa-brands fa-instagram"></i></a>
                           <a class="icon-4" href="#"><i class="fa-brands fa-pinterest"></i></a>
                        </div>
                        <div class="tp-team-info text-center">
                           <h4 class="tp-team-info-title"><a href="team-details.html">Marvin McKinney</a></h4>
                           <p>Designer</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-3 col-md-6">
                     <div class="tp-team-item p-relative wow fadeInUp" data-wow-duration="1s" data-wow-delay=".9s">
                        <div class="tp-team-item-thumb">
                           <a href="team-details.html"><img src="%{:assets-dir}/img/team/img-4.jpg" alt=""></a>
                        </div>
                        <div class="tp-team-social">
                           <a class="icon-1" href="#"><i class="fa-brands fa-facebook-f"></i></a>
                           <a class="icon-2" href="#"><i class="fa-brands fa-twitter"></i></a>
                           <a class="icon-3" href="#"><i class="fa-brands fa-instagram"></i></a>
                           <a class="icon-4" href="#"><i class="fa-brands fa-pinterest"></i></a>
                        </div>
                        <div class="tp-team-info text-center">
                           <h4 class="tp-team-info-title"><a href="team-details.html">Leslie Alexander</a></h4>
                           <p>Designer</p>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <!-- team area end -->



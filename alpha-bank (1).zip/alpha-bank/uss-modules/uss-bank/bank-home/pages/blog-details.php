
         <!-- postbox area start -->
         <section class="tp-postbox-area pt-120 pb-120">
            <div class="container">
               <div class="row">
                  <div class="col-xxl-8 col-xl-8 col-lg-8">
                     <div class="tp-postbox-wrapper">
                        <article class="tp-postbox-item-wrapper mb-80">
                           <div class="tp-postbox-item-thumb p-relative">
                              <img src="%{:assets-dir}/img/blog/blog-details/img-1.jpg" alt="">
                              <div class="tp-postbox-meta2">
                                 <span><i class="fa-regular fa-user"></i> By Admin</span>
                                 <span><i class="fa-regular fa-folder-open"></i> Category</span>
                                 <span><i class="fa-regular fa-calendar-days"></i> October 19, 2023</span>
                                 <span><i class="fa-light fa-comments"></i> Comments (05)</span>
                              </div>
                           </div>
                           <h3 class="tp-postbox-title2">Industry stan Women We make small</h3>
                           <p>Aliquam eros justo, posuere loborti viverra laoreet matti ullamcorper posuere viverra .Aliquam eros justo, posuere lobortis non, viverra laoreet augue mattis fermentum ullamcorper viver laoreet Aliquam eros justo, posuere loborti viverra laoreet matti ullamcorper posuere viverra .Aliquam eros justo, posuere lobortis non</p>

                           <p>Aliquam eros justo, posuere loborti viverra laoreet matti ullamcorper posuere viverra .Aliquam eros justo, posuere lobortis non, viverra laoreet auguerper viverra laoreet Aliquam eros justo, posuere loborti </p>

                           <div class="tp-postbox-list-wrapper d-flex">
                              <div class="tp-postbox-list mr-40">
                                 <h4 class="tp-postbox-list-title"><i class="fa-regular fa-check"></i> Best Emplementation</h4>
                                 <p>Oshed fact that a reader will be dist acted bioiiy design ished fact that a reader will.</p>
                              </div>
                              <div class="tp-postbox-list">
                                 <h4 class="tp-postbox-list-title"><i class="fa-regular fa-check"></i> Follow Your Stretegy</h4>
                                 <p>Oshed fact that a reader will be dist acted bioiiy design ished fact that a reader will.</p>
                              </div>
                           </div>

                           <div class="tp-postbox-blockquote p-relative">
                              <blockquote>
                                 <p>Aliquam eros justo, posuere loborti viverra laoreetti ullamcorper posuere viverra .Aliquam eros justo, posuere lobortis non, viverra laoreet augue mattis feentum ullamcorper viverra laoreet. Aliquam eros justo, posuere loborti viverra laoreet matti ullamcorpe</p>
                                 <img src="%{:assets-dir}/img/blog/blog-details/quote.png" alt="">
                              </blockquote>
                           </div>
                           
                           <p>Aliquam eros justo, posuere loborti viverra laoreet matti ullamcorper posuere viverra .Aliquam eros justo, posuere lobortis non, viverra laoreet augue mattis fermentum ullamcorper viverra laoreet </p>

                           <p>Aliquam eros justo, posuere loborti viverra laoreet matti ullamcorper posuere viverra .Aliquam eros justo, posuere lobortis non, viverra laoreet augue mattis fermentum ullamcorper viverra laoreet Aliquam eros justo, posuere loborti viverra laoreet matti ullamcorper posuere viverra .Aliquam eros justo, posuere</p>

                           <div class="tp-postbox-share-wrapper">
                              <div class="row">
                                 <div class="col-lg-7 col-md-7">
                                    <div class="tp-postbox-share-tags tagcloud">
                                       <a href="#">Start shape</a>
                                       <a href="#">Architecture</a>
                                       <a href="#">Large</a>
                                    </div>
                                 </div>
                                 <div class="col-lg-5 col-md-5">
                                    <div class="tp-postbox-share-social text-md-end">
                                       <div class="tp-footer-widget-social">
                                          <a href="#"><i class="fab fa-facebook-f"></i></a>
                                          <a href="#"><i class="fab fa-twitter"></i></a>
                                          <a href="#"><i class="fa-brands fa-instagram"></i></a>
                                          <a href="#"><i class="fa-brands fa-pinterest"></i></a>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </article>

                        <div class="tp-postbox-comment mb-60">
                           <ul>
                              <li>
                                 <div class="tp-postbox-comment-box border-mr p-relative">
                                    <div class="tp-postbox-comment-box-inner d-flex">
                                       <div class="tp-postbox-comment-avater">
                                          <img src="%{:assets-dir}/img/blog/blog-details/img-2.jpg" alt="">
                                       </div>
                                       <div class="tp-postbox-comment-content">
                                          <div class="tp-postbox-comment-author d-flex align-items-center">
                                             <h5 class="tp-postbox-comment-name">Stanio lainto</h5>
                                             <p class="tp-postbox-comment-date">October 19, 2023</p>
                                          </div>
                                          <p>ished fact that a reader will be distrol acted bioii the.ished fact that a reader <br> will be distrol acted laoreet Aliquam </p>
                                          <div class="tp-postbox-comment-reply"><a href="#">REPLY<i class="fa-solid fa-paper-plane"></i></a></div>
                                       </div>
                                    </div>
                                 </div>
                              </li>
                              <li class="children">
                                 <div class="tp-postbox-comment-box border-mr p-relative">
                                    <div class="tp-postbox-comment-box-inner d-flex">
                                       <div class="tp-postbox-comment-avater">
                                          <img src="%{:assets-dir}/img/blog/blog-details/img-3.jpg" alt="">
                                       </div>
                                       <div class="tp-postbox-comment-content">
                                          <div class="tp-postbox-comment-author d-flex align-items-center">
                                             <h5 class="tp-postbox-comment-name">Nick Jones</h5>
                                             <p class="tp-postbox-comment-date">October 19, 2023</p>
                                          </div>
                                          <p>ished fact that a reader will be distrol acted bioii the.ished fact <br> that a reader will be distrol acted laoreet Aliquam </p>
                                          <div class="tp-postbox-comment-reply"><a href="#">REPLY<i class="fa-solid fa-paper-plane"></i></a></div>
                                       </div>
                                    </div>
                                 </div>
                              </li>
                              <li>
                                 <div class="tp-postbox-comment-box p-relative">
                                    <div class="tp-postbox-comment-box-inner d-flex">
                                       <div class="tp-postbox-comment-avater">
                                          <img src="%{:assets-dir}/img/blog/blog-details/img-4.jpg" alt="">
                                       </div>
                                       <div class="tp-postbox-comment-content">
                                          <div class="tp-postbox-comment-author d-flex align-items-center">
                                             <h5 class="tp-postbox-comment-name">Don streak</h5>
                                             <p class="tp-postbox-comment-date">October 19, 2023</p>
                                          </div>
                                          <p>ished fact that a reader will be distrol acted bioii the.ished fact that a reader <br> will be distrol acted laoreet Aliquam </p>
                                          <div class="tp-postbox-comment-reply"><a href="#">REPLY<i class="fa-solid fa-paper-plane"></i></a></div>
                                       </div>
                                    </div>
                                 </div>
                              </li>
                           </ul>
                        </div>

                        <div class="tp-postbox-reply">
                           <h3 class="tp-postbox-reply-title">Leave a comment</h3>
                           <form id="contact-form" action="https://template.wphix.com/finbest-prv/finbest/%{:assets-dir}/mail.php" method="POST">
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="tp-postbox-input">
                                       <input name="name" type="text" placeholder="Your Name">
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="tp-postbox-input">
                                       <input name="email" type="email" placeholder="Your E-mail">
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="tp-postbox-input">
                                       <input name="number" type="text" placeholder="Phone Number">
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="tp-postbox-input">
                                       <input name="text" type="text" placeholder="Subject">
                                    </div>
                                 </div>
                                 <div class="col-md-12">
                                    <div class="tp-postbox-input">
                                       <textarea type="text" placeholder="Message"></textarea>
                                    </div>
                                 </div>
                                 <div class="col-md-12">
                                    <div class="tp-postbox-input-btn">
                                       <button type="submit" class="tp-btn">Submit Now</button>
                                       <p class="ajax-response"></p>
                                    </div>
                                 </div>
                              </div>
                           </form>
                        </div>
                     </div>
                  </div>

                  <div class="col-xxl-4 col-xl-4 col-lg-4">
                     <div class="tp-sidebar-wrapper">
                        <div class="tp-sidebar-widget-search mb-40">
                           <div class="tp-sidebar-widget-content">
                              <div class="tp-sidebar-search">
                                 <form action="#">
                                    <div class="tp-sidebar-search-input">
                                       <input type="text" placeholder="Search">
                                       <button type="submit"><i class="far fa-search"></i></button>
                                    </div>
                                 </form>
                              </div>
                           </div>
                        </div>

                        <div class="tp-sidebar-widget mb-40">
                           <h3 class="tp-sidebar-widget-title">Categories</h3>
                           <div class="tp-sidebar-widget-content">
                              <ul>
                                 <li><a href="blog-classic.html"><i class="fa-solid fa-chevrons-right"></i> Agency</a></li>
                                 <li><a href="blog-classic.html"><i class="fa-solid fa-chevrons-right"></i> Corporate</a></li>
                                 <li><a href="blog-classic.html"><i class="fa-solid fa-chevrons-right"></i> Business</a></li>
                              </ul>
                           </div>
                        </div>

                        <div class="tp-sidebar-widget mb-40">
                           <h3 class="tp-sidebar-widget-title">Recent Post</h3>
                           <div class="tp-sidebar-widget-content">
                              <div class="tp-sidebar-post tp-rc__post">
                                 <div class="tp-rc__post d-flex align-items-center">
                                    <div class="tp-rc__post-thumb mr-25">
                                       <a href="blog-details.html"><img src="%{:assets-dir}/img/blog/postbox/img-5.jpg" alt=""></a>
                                    </div>
                                    <div class="tp-rc__post-content">
                                       <h3 class="tp-rc__post-title">
                                          <a href="blog-details.html">Transforming businesses for the digital age</a>
                                       </h3>
                                       <div class="tp-rc__post-meta">
                                          <span><i class="fa-regular fa-calendar-days"></i> October 19, 2023</span>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="tp-rc__post d-flex align-items-center">
                                    <div class="tp-rc__post-thumb mr-25">
                                       <a href="blog-details.html"><img src="%{:assets-dir}/img/blog/postbox/img-6.jpg" alt=""></a>
                                    </div>
                                    <div class="tp-rc__post-content">
                                       <h3 class="tp-rc__post-title">
                                          <a href="blog-details.html">Unlocking the potential of your business</a>
                                       </h3>
                                       <div class="tp-rc__post-meta">
                                          <span><i class="fa-regular fa-calendar-days"></i> October 19, 2023</span>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="tp-rc__post d-flex align-items-center">
                                    <div class="tp-rc__post-thumb mr-25">
                                       <a href="blog-details.html"><img src="%{:assets-dir}/img/blog/postbox/img-7.jpg" alt=""></a>
                                    </div>
                                    <div class="tp-rc__post-content">
                                       <h3 class="tp-rc__post-title">
                                          <a href="blog-details.html">Navigating challenges to reach new heights</a>
                                       </h3>
                                       <div class="tp-rc__post-meta">
                                          <span><i class="fa-regular fa-calendar-days"></i> October 19, 2023</span>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>

                        <div class="tp-sidebar-work mb-40 p-relative" data-background="%{:assets-dir}/img/blog/postbox/img-8.jpg">
                           <h3 class="tp-sidebar-work-title text-center">Work with us</h3>
                           <div class="tp-sidebar-work-content text-center">
                              <div class="tp-sidebar-work-icon">
                                 <span><img src="%{:assets-dir}/img/blog/postbox/icon-1.svg" alt=""></span>
                              </div>
                              <p>Aliquam posuere loborti viverra atti ullamcer posuere viverra .Aliquam er.Aliquam r justo, posuere loborti viverra atti ullam</p>
                           </div>
                        </div>
                        
                        <div class="tp-sidebar-widget">
                           <h3 class="tp-sidebar-widget-title">Tags</h3>
                           <div class="tp-sidebar-widget-content">
                              <div class="tagcloud">
                                 <a href="#">Start shape</a>
                                 <a href="#">Architecture</a>
                                 <a href="#">Large</a>
                                 <a href="#">Business</a>
                                 <a href="#">Stretegy</a>
                              </div>
                           </div>
                        </div>

                     </div>
                  </div>
               </div>
            </div>
         </section>
         <!-- postbox area end -->


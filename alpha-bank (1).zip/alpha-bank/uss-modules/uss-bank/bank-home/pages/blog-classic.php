
         <!-- postbox area start -->
         <section class="tp-postbox-area pt-120 pb-90">
            <div class="container">
               <div class="row">
                  <div class="col-xxl-8 col-xl-8 col-lg-8">
                     <div class="tp-postbox-wrapper">
                        <article class="tp-postbox-item mb-50">
                           <div class="tp-postbox-thumb p-relative">
                              <a href="blog-details.html">
                                 <img src="%{:assets-dir}/img/blog/postbox/img-1.jpg" alt="">
                              </a>
                              <div class="tp-postbox-thumb-date text-center">
                                 <span>28</span>
                                 <p>June</p>
                              </div>
                           </div>
                           <div class="tp-postbox-content">
                              <div class="tp-postbox-meta">
                                 <span><i class="fa-regular fa-user"></i> By Admin</span>
                                 <span><a href="#">Comments (05)</a></span>
                              </div>
                              <h3 class="tp-postbox-title">
                                 <a href="blog-details.html">Building digital experiences that matter</a>
                              </h3>
                              <div class="tp-postbox-text">
                                 <p>Aliquam eros justo, posuere loborti vive rra laoreet matti ullamc orper posu ere viverra .Aliquam eros justo, posuere lobortis non, vive rra laoreet augue mattis fermentum ullamcorper viverra laoet Aliqam eros justo, posuere loborti viverra laoreet mat ullamcorper posue viverra</p>
                              </div>
                              <div class="tp-postbox-read-more">
                                 <a href="blog-details.html" class="tp-postbox-btn"><i class="fa-solid fa-arrow-right"></i> Read More</a>
                              </div>
                           </div>
                        </article>

                        <article class="tp-postbox-item mb-50">
                           <div class="tp-postbox-thumb p-relative">
                              <a href="blog-details.html">
                                 <img src="%{:assets-dir}/img/blog/postbox/img-2.jpg" alt="">
                              </a>
                              <div class="tp-postbox-thumb-btn">
                                 <a class="play-btn popup-video" href="https://www.youtube.com/watch?v=go7QYaQR494"><i class="fa-solid fa-play"></i></a>
                              </div>
                              <div class="tp-postbox-thumb-date text-center">
                                 <span>28</span>
                                 <p>June</p>
                              </div>
                           </div>
                           <div class="tp-postbox-content">
                              <div class="tp-postbox-meta">
                                 <span><i class="fa-regular fa-user"></i> By Admin</span>
                                 <span><a href="#">Comments (05)</a></span>
                              </div>
                              <h3 class="tp-postbox-title">
                                 <a href="blog-details.html">Partnering with businesses to achieve their goals</a>
                              </h3>
                              <div class="tp-postbox-text">
                                 <p>Aliquam eros justo, posuere loborti vive rra laoreet matti ullamc orper posu ere viverra .Aliquam eros justo, posuere lobortis non, vive rra laoreet augue mattis fermentum ullamcorper viverra laoet Aliqam eros justo, posuere loborti viverra laoreet mat ullamcorper posue viverra</p>
                              </div>
                              <div class="tp-postbox-read-more">
                                 <a href="blog-details.html" class="tp-postbox-btn"><i class="fa-solid fa-arrow-right"></i> Read More</a>
                              </div>
                           </div>
                        </article>

                        <article class="tp-postbox-item mb-50">
                           <div class="tp-postbox-thumb p-relative">
                              <a href="blog-details.html">
                                 <img src="%{:assets-dir}/img/blog/postbox/img-3.jpg" alt="">
                              </a>
                              <div class="tp-postbox-thumb-date text-center">
                                 <span>28</span>
                                 <p>June</p>
                              </div>
                           </div>
                           <div class="tp-postbox-content">
                              <div class="tp-postbox-meta">
                                 <span><i class="fa-regular fa-user"></i> By Admin</span>
                                 <span><a href="#">Comments (05)</a></span>
                              </div>
                              <h3 class="tp-postbox-title">
                                 <a href="blog-details.html">Empowering businesses with data-driven insights</a>
                              </h3>
                              <div class="tp-postbox-text">
                                 <p>Aliquam eros justo, posuere loborti vive rra laoreet matti ullamc orper posu ere viverra .Aliquam eros justo, posuere lobortis non, vive rra laoreet augue mattis fermentum ullamcorper viverra laoet Aliqam eros justo, posuere loborti viverra laoreet mat ullamcorper posue viverra</p>
                              </div>
                              <div class="tp-postbox-read-more">
                                 <a href="blog-details.html" class="tp-postbox-btn"><i class="fa-solid fa-arrow-right"></i> Read More</a>
                              </div>
                           </div>
                        </article>
                       
                        <article class="tp-postbox-item mb-50">
                           <div class="tp-postbox-thumb p-relative">
                              <div class="tp-blog-post-active swiper-container">
                                 <div class="swiper-wrapper">
                                    <div class="swiper-slide">
                                       <a href="blog-details.html">
                                          <img src="%{:assets-dir}/img/blog/postbox/img-4.jpg" alt="">
                                       </a>
                                    </div>
                                    <div class="swiper-slide">
                                       <a href="blog-details.html">
                                          <img src="%{:assets-dir}/img/blog/postbox/img-3.jpg" alt="">
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="tp-postbox-thumb-date text-center">
                                 <span>28</span>
                                 <p>June</p>
                              </div>
                              <div class="tp-postbox-nav text-end">
                                 <button type="button" class="tp-blog-prev-1"><i class="fa-regular fa-arrow-left"></i>
                                 </button>
                                 <button type="button" class="tp-blog-next-1"><i class="fa-regular fa-arrow-right"></i>
                                 </button>
                              </div>
                           </div>
                           <div class="tp-postbox-content">
                              <div class="tp-postbox-meta">
                                 <span><i class="fa-regular fa-user"></i> By Admin</span>
                                 <span><a href="#">Comments (05)</a></span>
                              </div>
                              <h3 class="tp-postbox-title">
                                 <a href="blog-details.html">Maximizing profitability through efficiency and optimization</a>
                              </h3>
                              <div class="tp-postbox-text">
                                 <p>Aliquam eros justo, posuere loborti vive rra laoreet matti ullamc orper posu ere viverra .Aliquam eros justo, posuere lobortis non, vive rra laoreet augue mattis fermentum ullamcorper viverra laoet Aliqam eros justo, posuere loborti viverra laoreet mat ullamcorper posue viverra</p>
                              </div>
                              <div class="tp-postbox-read-more">
                                 <a href="blog-details.html" class="tp-postbox-btn"><i class="fa-solid fa-arrow-right"></i> Read More</a>
                              </div>
                           </div>
                        </article>
                        
                        <div class="tp-postbox-pagination">
                           <nav>
                              <ul>
                                 <li>
                                    <a href="blog-classic.html">01</a>
                                 </li>
                                 <li>
                                    <span class="current">02</span>
                                 </li>
                                 <li>
                                    <a href="blog-classic.html">03</a>
                                 </li>
                              </ul>
                           </nav>
                        </div>
                     </div>
                  </div>

                  <div class="col-xxl-4 col-xl-4 col-lg-4">
                     <div class="tp-sidebar-wrapper">
                        <div class="tp-sidebar-widget-search mb-40">
                           <div class="tp-sidebar-widget-content">
                              <div class="tp-sidebar-search">
                                 <form action="#">
                                    <div class="tp-sidebar-search-input">
                                       <input type="text" placeholder="Search">
                                       <button type="submit"><i class="far fa-search"></i></button>
                                    </div>
                                 </form>
                              </div>
                           </div>
                        </div>

                        <div class="tp-sidebar-widget mb-40">
                           <h3 class="tp-sidebar-widget-title">Categories</h3>
                           <div class="tp-sidebar-widget-content">
                              <ul>
                                 <li><a href="blog-classic.html"><i class="fa-solid fa-chevrons-right"></i> Agency</a></li>
                                 <li><a href="blog-classic.html"><i class="fa-solid fa-chevrons-right"></i> Corporate</a></li>
                                 <li><a href="blog-classic.html"><i class="fa-solid fa-chevrons-right"></i> Business</a></li>
                              </ul>
                           </div>
                        </div>

                        <div class="tp-sidebar-widget mb-40">
                           <h3 class="tp-sidebar-widget-title">Recent Post</h3>
                           <div class="tp-sidebar-widget-content">
                              <div class="tp-sidebar-post tp-rc__post">
                                 <div class="tp-rc__post d-flex align-items-center">
                                    <div class="tp-rc__post-thumb mr-25">
                                       <a href="blog-details.html"><img src="%{:assets-dir}/img/blog/postbox/img-5.jpg" alt=""></a>
                                    </div>
                                    <div class="tp-rc__post-content">
                                       <h3 class="tp-rc__post-title">
                                          <a href="blog-details.html">Transforming businesses for the digital age</a>
                                       </h3>
                                       <div class="tp-rc__post-meta">
                                          <span><i class="fa-regular fa-calendar-days"></i> October 19, 2023</span>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="tp-rc__post d-flex align-items-center">
                                    <div class="tp-rc__post-thumb mr-25">
                                       <a href="blog-details.html"><img src="%{:assets-dir}/img/blog/postbox/img-6.jpg" alt=""></a>
                                    </div>
                                    <div class="tp-rc__post-content">
                                       <h3 class="tp-rc__post-title">
                                          <a href="blog-details.html">Unlocking the potential of your business</a>
                                       </h3>
                                       <div class="tp-rc__post-meta">
                                          <span><i class="fa-regular fa-calendar-days"></i> October 19, 2023</span>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="tp-rc__post d-flex align-items-center">
                                    <div class="tp-rc__post-thumb mr-25">
                                       <a href="blog-details.html"><img src="%{:assets-dir}/img/blog/postbox/img-7.jpg" alt=""></a>
                                    </div>
                                    <div class="tp-rc__post-content">
                                       <h3 class="tp-rc__post-title">
                                          <a href="blog-details.html">Navigating challenges to reach new heights</a>
                                       </h3>
                                       <div class="tp-rc__post-meta">
                                          <span><i class="fa-regular fa-calendar-days"></i> October 19, 2023</span>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>

                        <div class="tp-sidebar-work mb-40 p-relative" data-background="%{:assets-dir}/img/blog/postbox/img-8.jpg">
                           <h3 class="tp-sidebar-work-title text-center">Work with us</h3>
                           <div class="tp-sidebar-work-content text-center">
                              <div class="tp-sidebar-work-icon">
                                 <span><img src="%{:assets-dir}/img/blog/postbox/icon-1.svg" alt=""></span>
                              </div>
                              <p>Aliquam posuere loborti viverra atti ullamcer posuere viverra .Aliquam er.Aliquam r justo, posuere loborti viverra atti ullam</p>
                           </div>
                        </div>
                        
                        <div class="tp-sidebar-widget">
                           <h3 class="tp-sidebar-widget-title">Tags</h3>
                           <div class="tp-sidebar-widget-content">
                              <div class="tagcloud">
                                 <a href="#">Start shape</a>
                                 <a href="#">Architecture</a>
                                 <a href="#">Large</a>
                                 <a href="#">Business</a>
                                 <a href="#">Stretegy</a>
                              </div>
                           </div>
                        </div>

                     </div>
                  </div>
               </div>
            </div>
         </section>
         <!-- postbox area end -->


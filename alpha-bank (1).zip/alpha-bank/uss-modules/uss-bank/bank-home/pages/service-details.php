

         <!-- service area start -->
         <section class="tp-service-details-area pt-120 pb-120">
            <div class="container">
               <div class="row">
                  <div class="col-lg-8">
                     <div class="tp-service-details-wrapper">
                        <div class="tp-service-details-thumb">
                           <img src="%{:assets-dir}/img/service/service-details/img-1.jpg" alt="">
                        </div>
                        <h3 class="tp-service-details-title">Industry stan Developing </h3>
                        <p>Aliquam eros justo, posuere loborti viverra laoreet matti ullamcorper posuere viverra .Aliquam eros justo, posuere lobortis  viverra laoreet augue mattis fermentum ullamcorper viverra laoreet Aliquam eros justo, posuere loborti viverra laoreet matti ullamcorper posuere viverra .Aliquam eros justo, posuere lobortis non</p>
                        <p>Aliquam eros justo, posuere loborti viverra laoreet matti ullamcorper posuere viverra .Aliquam eros justo, posuere lobortis no vive rra laoreet augue mattis fermentum ullamcorper viverra laoreet Aliquam eros justo</p>
                        
                        <div class="tp-service-details-box d-flex mb-60">
                           <div class="tp-service-details-item d-flex mr-30">
                              <div class="tp-service-details-icon">
                                 <img src="%{:assets-dir}/img/service/service-details/icon-1.svg" alt="">
                              </div>
                              <div class="tp-service-details-content">
                                 <h3 class="tp-service-details-subtitle">Analysis Data</h3>
                                 <p>Lorem Ipsum is simply is dumiom in thi yadvice design in us repairs and  is text Lorem Ipsum is simply design company  text Lorem Ipsum</p>
                              </div>
                           </div>

                           <div class="tp-service-details-item d-flex">
                              <div class="tp-service-details-icon">
                                 <img src="%{:assets-dir}/img/service/service-details/icon-2.svg" alt="">
                              </div>
                              <div class="tp-service-details-content">
                                 <h3 class="tp-service-details-subtitle">Delivary Customer</h3>
                                 <p>Lorem Ipsum is simply is dumiom in thi yadvice design in us repairs and  is text Lorem Ipsum is simply design company  text Lorem</p>
                              </div>
                           </div>
                        </div>

                        <div class="tp-service-details-box-2 d-flex mb-40">
                           <div class="tp-service-details-box-content mr-30">
                              <h3 class="tp-service-details-subtitle-2">Expert test matters</h3>
                              <p>Aliquam eros justo, posu ere loborti viver lao reet matti ullam corpe.Aliquam eros justo, posuere lobortis non</p>
                              <p>Aliquam eros justo, posuere loboh viverra laoreet matti ullamcorper posuere viverr.Aliquam eros justo, posuere lobortis non, viverra laoreet augue mattis fermentum ullamcorper.</p>
                           </div>
                           <div class="tp-service-details-box-thumb">
                              <img src="%{:assets-dir}/img/service/service-details/img-2.jpg" alt="">
                           </div>
                        </div>

                        <div class="tp-service-details-quote">
                           <span>Aliquam eros justo, posuere loborti viverra laoreet matti uacorper posuere viverra .Aliquam eros no justo des posuere lobortis non, viverra laoreet ue mattis fermentum ullamcorper viverra laoreet. Aliquam eros industry posuere loborti viverra laoreet matti ullamcorpe</span>
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-4">
                     <div class="tp-service-widget">
                        <div class="tp-service-widget-item mb-40">
                           <div class="tp-service-widget-tab">
                              <h3 class="tp-service-widget-title">Our service</h3>
                              <ul>
                                 <li class="active"><a href="service-details.html">Finance & Banking</a></li>
                                 <li><a href="service-details.html">Business Advice</a></li>
                                 <li><a href="service-details.html">Stock market</a></li>
                                 <li><a href="service-details.html">Regular start</a></li>
                                 <li><a href="service-details.html">Precious metal</a></li>
                              </ul>
                           </div>
                        </div>

                        <div class="tp-service-widget-contact mb-40" data-background="%{:assets-dir}/img/service/service-details/img-3.jpg">
                           <div class="tp-service-widget-contact-content text-center">
                              <div class="tp-service-widget-contact-icon">
                                 <span><i class="fa-solid fa-phone"></i></span>
                              </div>
                              <p>Requesting A Call:</p>
                              <a href="tel:55555555">000 555-0129</a>
                           </div>
                        </div>
   
                        <div class="tp-service-widget-download mb-40">
                           <a href="#"><span>Download Profile <img src="%{:assets-dir}/img/service/service-details/icon-3.svg" alt=""></span></a>
                        </div>

                        <div class="tp-service-widget-list">
                           <div class="tp-service-widget-list-content">
                              <ul>
                                 <li><i class="fa-light fa-circle-check"></i> Mistakes To Avoid to dum </li>
                                 <li><i class="fa-light fa-circle-check"></i> Startup industry stan Aliquam </li>
                                 <li><i class="fa-light fa-circle-check"></i> Knew About Fots text posuere</li>
                              </ul>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <!-- service area end -->

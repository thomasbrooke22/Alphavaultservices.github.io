
         <!-- faq area start -->
         <section class="tp-faq-breadcrumb-area pt-120 pb-100">
            <div class="container">
               <div class="row">
                  <div class="col-lg-6">
                     <div class="tp-faq-breadcrumb-tab-content tp-accordion">
                        <div class="accordion" id="general_accordion">
                           <div class="accordion-item tp-faq-active">
                              <h2 class="accordion-header" id="headingOne">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                 What is business consulting?
                                </button>
                              </h2>
                              <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#general_accordion">
                                <div class="accordion-body">
                                  <p>Business consulting is a service provided by professionals who offer expert advice and guidance to organizations seeking to improve their business processes, strategies, and operations</p>
                                </div>
                              </div>
                            </div>
                           <div class="accordion-item">
                             <h2 class="accordion-header" id="headingTwo">
                               <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                 What types of businesses typically use consulting services?
                               </button>
                             </h2>
                             <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#general_accordion">
                               <div class="accordion-body">
                                 <p>Business consulting is a service provided by professionals who offer expert advice and guidance to organizations seeking to improve their business processes, strategies, and operations</p>
                               </div>
                             </div>
                           </div>
                           <div class="accordion-item">
                             <h2 class="accordion-header" id="headingThree">
                               <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                 What are the benefits of using a business consulting service?
                               </button>
                             </h2>
                             <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#general_accordion">
                               <div class="accordion-body">
                                 <p>Business consulting is a service provided by professionals who offer expert advice and guidance to organizations seeking to improve their business processes, strategies, and operations</p>
                               </div>
                             </div>
                           </div>
                           <div class="accordion-item">
                             <h2 class="accordion-header" id="headingFour">
                               <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                 How much do consulting services cost?
                               </button>
                             </h2>
                             <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#general_accordion">
                               <div class="accordion-body">
                                 <p>Business consulting is a service provided by professionals who offer expert advice and guidance to organizations seeking to improve their business processes, strategies, and operations</p>
                               </div>
                             </div>
                           </div>
                         </div>
                     </div>
                  </div>
                  <div class="col-lg-6">
                     <div class="tp-faq-breadcrumb-tab-content tp-accordion">
                        <div class="accordion" id="general_accordion-2">
                           <div class="accordion-item tp-faq-active">
                              <h2 class="accordion-header" id="headingfive">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapsefive" aria-expanded="true" aria-controls="fiveOne">
                                 How much do consulting services cost?
                                </button>
                              </h2>
                              <div id="collapsefive" class="accordion-collapse collapse show" aria-labelledby="headingfive" data-bs-parent="#general_accordion-2">
                                <div class="accordion-body">
                                  <p>Business consulting is a service provided by professionals who offer expert advice and guidance to organizations seeking to improve their business processes, strategies, and operations</p>
                                </div>
                              </div>
                            </div>
                           <div class="accordion-item">
                             <h2 class="accordion-header" id="headingsix">
                               <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapsesix" aria-expanded="false" aria-controls="collapsesix">
                                 What types of businesses typically use consulting services?
                               </button>
                             </h2>
                             <div id="collapsesix" class="accordion-collapse collapse" aria-labelledby="headingsix" data-bs-parent="#general_accordion-2">
                               <div class="accordion-body">
                                 <p>Business consulting is a service provided by professionals who offer expert advice and guidance to organizations seeking to improve their business processes, strategies, and operations</p>
                               </div>
                             </div>
                           </div>
                           <div class="accordion-item">
                             <h2 class="accordion-header" id="headingseven">
                               <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseseven" aria-expanded="false" aria-controls="collapseseven">
                                 What are the benefits of using a business consulting service?
                               </button>
                             </h2>
                             <div id="collapseseven" class="accordion-collapse collapse" aria-labelledby="headingseven" data-bs-parent="#general_accordion-2">
                               <div class="accordion-body">
                                 <p>Business consulting is a service provided by professionals who offer expert advice and guidance to organizations seeking to improve their business processes, strategies, and operations</p>
                               </div>
                             </div>
                           </div>
                           <div class="accordion-item">
                             <h2 class="accordion-header" id="headingeight">
                               <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseeight" aria-expanded="false" aria-controls="collapseeight">
                                 How much do consulting services cost?
                               </button>
                             </h2>
                             <div id="collapseeight" class="accordion-collapse collapse" aria-labelledby="headingeight" data-bs-parent="#general_accordion-2">
                               <div class="accordion-body">
                                 <p>Business consulting is a service provided by professionals who offer expert advice and guidance to organizations seeking to improve their business processes, strategies, and operations</p>
                               </div>
                             </div>
                           </div>
                         </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <!-- faq area end -->


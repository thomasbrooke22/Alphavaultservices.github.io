<?php
    Events::addListener('@body:beforeAfter', function() {

?>  
                 

    </main>
      
        <!-- footer area start -->
    <footer class="tp-footer-area pt-80 p-relative z-index-1" data-bg-color="#16243E">
        <div class="tp-footer-bg-shape d-none">
            <img src="%{:assets-dir}/img/footer/bg-shape.png" alt="">
        </div>
        <div class="tp-footer-main-area tp-footer-border">
            <div class="container">
                <div class="row justify-content-between">
                    <div class="col-xl-4 col-lg-4 col-md-6">
                    <div class="tp-footer-widget tp-footer-col-1 mb-50">
                        <div class="tp-footer-logo mb-20">
                        <a href="<?php echo Core::url( ROOT_DIR ); ?>"> <img src="%{@site:icon}" alt="" height='60px'></a>
                        </div>
                        <div class="tp-footer-widget-content">
                            <p>%{@site:description}</p>
                            <div class="tp-footer-widget-social">
                                <a href="#"><i class="fab fa-facebook-f"></i></a>
                                <a href="#"><i class="fab fa-twitter"></i></a>
                                <a href="#"><i class="fa-brands fa-instagram"></i></a>
                                <a href="#"><i class="fa-brands fa-pinterest"></i></a>
                            </div>
                        </div>
                    </div>
                    </div>
                    <div class="col-xl-3 col-lg-4 col-md-6">
                    <div class="tp-footer-widget tp-footer-col-2 mb-50">
                        <h3 class="tp-footer-widget-title">Quick links</h3>
                        <div class="tp-footer-widget-content">
                            <ul class='text-capitalize'>
                                <?php
                                    foreach( Home::$footerMenu->child as $menu ):
                                        $href = $menu->getAttr('href');
                                        if( empty($href) ) $href = 'javascript:void(0)';
                                        else $href = Core::url( ROOT_DIR . "{$href}" );
                                ?>
                                    <li>
                                        <a href='<?php echo $href; ?>'>
                                            <?php echo $menu->getAttr('label'); ?>
                                        </a>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </div> 
                    </div>
                    <div class="col-xl-3 col-lg-4 col-md-6">
                    <div class="tp-footer-widget tp-footer-col-4 mb-50">
                        <h3 class="tp-footer-widget-title">Contact us</h3>
                        <div class="tp-footer-widget-content">
                            <div class="tp-footer-widget-contact">
                                <div class="tp-footer-widget-contact-inner">
                                <a href="javascript:void(0)"><i class="fa-sharp fa-solid fa-location-dot"></i>%{@site:address}</a>
                                </div>
                                <div class="tp-footer-widget-contact-inner">
                                <a href="tel:%{@site:phone}"><i class="fa-solid fa-phone"></i>%{@site:phone}</a>
                                </div>
                                <div class="tp-footer-widget-contact-inner">
                                <a href="mailto:%{@email:admin}"><i class="fa-solid fa-envelope"></i>%{@email:admin}</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tp-footer-copyright-area p-relative">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-lg-6">
                    <div class="tp-footer-copyright-inner">
                        <p>© %{@site:title} 2023 | All Rights Reserved</p>
                    </div>
                    </div>
                    <div class="col-md-12 col-lg-6">
                    <div class="tp-footer-copyright-inner text-lg-end text-capitalize">
                        <?php
                            foreach( Home::$footerMenu->child as $menu ):
                                $href = $menu->getAttr('href');
                                if( empty($href) ) $href = 'javascript:void(0)';
                                else $href = Core::url( ROOT_DIR . "{$href}" );
                        ?>
                            <a href='<?php echo $href; ?>'>
                                <?php echo $menu->getAttr('label'); ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- footer area end -->

<?php }, 1999 ); 

Events::addListener('@body:after', function() {
?>

    <!-- JS here -->
    <script src="%{:assets-dir}/js/vendor/waypoints.js"></script>
    <script src="%{:assets-dir}/js/meanmenu.js"></script>
    <script src="%{:assets-dir}/js/swiper-bundle.js"></script>
    <script src="%{:assets-dir}/js/slick.js"></script>
    <script src="%{:assets-dir}/js/jquery-appear.js"></script>
    <script src="%{:assets-dir}/js/jquery-knob.js"></script>
    <script src="%{:assets-dir}/js/range-slider.js"></script>
    <script src="%{:assets-dir}/js/magnific-popup.js"></script>
    <script src="%{:assets-dir}/js/nice-select.js"></script>
    <script src="%{:assets-dir}/js/purecounter.js"></script>
    <script src="%{:assets-dir}/js/countdown.js"></script>
    <script src="%{:assets-dir}/js/wow.js"></script>
    <script src="%{:assets-dir}/js/tweenmax.min.js"></script>
    <script src="%{:assets-dir}/js/isotope-pkgd.js"></script>
    <script src="%{:assets-dir}/js/imagesloaded-pkgd.js"></script>
    <script src="%{:assets-dir}/js/ajax-form.js"></script>
    <script src="%{:assets-dir}/js/main.js"></script>

<?php }, 'bank-footer');
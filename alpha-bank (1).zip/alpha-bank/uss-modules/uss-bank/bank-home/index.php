<?php

Home::init();

# "route" => [ "page title", "filename" ]

$routers = array(

   "/" => ["", "home.php"],
   
     "personal" => ["personal / private banking", "personal.php"],
     
     "corporate" => ["corporate banking", "corporate.php"],

    "deposits" => ["deposits", "deposits.php"],
    
    "credits" => ['credits', "credits.php"],
    
    "cards" => ["cards payments", "cards.php"],

    "investments" => ["investments growth", "investments.php"],
    
    "loans" => ["loans", "loans.php"],
    
    "insurance" => ["insurance", "insurance.php"],
    
    "contact" => ["contact", "contact.php"],

    
    
    

);

Home::buildPages( $routers );
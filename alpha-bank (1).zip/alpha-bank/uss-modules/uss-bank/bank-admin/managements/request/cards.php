<?php

$card = new class {

    public function __construct() {

        if( $_SERVER['REQUEST_METHOD'] == 'POST' ) {
            $this->processCard();
        };

    }

    public function processCard() {
        
        $id = Uss::query(3);

        $post = array_map(array( Uss::$global['mysqli'], 'real_escape_string' ), $_POST );
        
        $SQL = SQuery::update( DB_TABLE_PREFIX . "_cards", $post, "id = {$id}" );

        $update = Uss::$global['mysqli']->query( $SQL );

        if( $update ) {

            Bank::log( 'success', "Card detail successfully updated!" );

        } else {

            Bank::log( 'error', "The bank detail failed to update" );

        };

    }

};
<?php

$exchange = new class {

    protected $post;
    public $table = DB_TABLE_PREFIX . "_exchanges";

    public function __construct() {

        if( $_SERVER['REQUEST_METHOD'] == 'POST' ) {
            
            $this->post = array_map(function($value) {
                return Uss::$global['mysqli']->real_escape_string( trim($value) );
            }, $_POST);

            $this->handleExchange();

        };

    }

    public function handleExchange() {

        $SQL = SQuery::update( $this->table, $this->post, "id = {$this->post['id']}" );

        $update = Uss::$global['mysqli']->query( $SQL );

        $message = "The exchange %s {$this->post['status']}";

        if( $update ) {

            Bank::log( "success", sprintf($message, "has been") );

        } else {

            Bank::log( 'error', sprintf($message, "could not be") );

        };

    }

};
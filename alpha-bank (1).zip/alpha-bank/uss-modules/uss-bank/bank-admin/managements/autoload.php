<?php 

define( 'MANG_DIR', __DIR__ );

$managementRoute = UADMIN_ROUTE . "/management";

$managementMenu = Uss::$global['menu']->add('management', [
    "label" => "Managements",
    "icon" => "<i class='bi bi-ui-radios-grid'></i>",
    "order" => 3
]);

require_once __DIR__ . "/card.php";
require_once __DIR__ . "/loan.php";
require_once __DIR__ . "/currencies.php";
require_once __DIR__ . "/exchanges.php";

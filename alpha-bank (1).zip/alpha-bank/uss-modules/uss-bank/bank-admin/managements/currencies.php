<?php

$currencyRoute = $managementRoute . "/currencies";

$currencyMenu = $managementMenu->add("currency", [
    "label" => "Currencies",
    "href" => Core::url( ROOT_DIR . "/{$currencyRoute}" )
]);

# Focus;

Uss::route( $currencyRoute . "(?:(?:/new)|(?:/edit/(\d+)))?", function() use($currencyMenu) {

    $currencyMenu->setAttr('active', true);
    $currencyMenu->parentMenu->setAttr('active', true);

    require_once MANG_DIR . "/request/currency.php";
    
    Udash::view(function() use($coinObject) {
        
        $currencies = Uss::$global['options']->get('bank:currencies');

        $type = Uss::query(3);
        
        if( empty($type) ) {
            require MANG_DIR . "/templates/currencies.php";
        } else {
            require MANG_DIR . "/templates/currency-mode.php";
        };

    });

}, null);
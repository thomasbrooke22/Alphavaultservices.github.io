<div class='container-fluid'>
    
    <h3 class='text-capitalize'><?php echo $type; ?> currency</h3>

    <hr>

    <div class='row'>

        <div class='col-md-8 col-lg-6 mx-auto'>
            <div class='card'>
                <div class='card-body'>

                    <form method='POST'>
                        <fieldset class='p-3 p-sm-4'>

                            <div class='alert alert-info'>
                                Need help with currency information? <a href='https://www.currencyremitapp.com/world-currency-symbols/' target='_blank'>Click Here</a>
                            </div>

                            <div class='mb-3'>
                                <label class='form-label --required'>Currency Code</label>
                                <input type='text' name='code' value='%{currency-code}' placeholder='USD' class='form-control' pattern='^[a-zA-Z]{3}$' required>
                            </div>

                            <div class='mb-3'>
                                <label class='form-label --required'>Currency Name</label>
                                <input type='text' name='name' value='%{currency-name}' placeholder='US Dollar' class='form-control' required>
                            </div>

                            <div class='mb-4'>
                                <label class='form-label --required'>Currency Symbol</label>
                                <input type='text' name='symbol' value='%{currency-symbol}' placeholder='$' class='form-control' required>
                            </div>

                            <div class='mb-4'>
                                <label class='form-label --required'>Rate Per USD</label>
                                <input type='number' step='0.01' value='%{currency-rate}' name='rate' placeholder='250.34' class='form-control' required>
                            </div>

                            <button class='btn btn-primary w-100'>
                                Save Currency
                            </button>

                        </fieldset>
                    </form>

                </div>
            </div>
        </div>

        <div class='col-lg-6 d-none d-lg-block'>
            <div class='p-3 text-center'>
                <img src='https://cdn.pixabay.com/animation/2023/06/08/15/03/15-03-45-927_512.gif' class='img-fluid' width='300px'>
            </div>
        </div>

    </div>

</div>
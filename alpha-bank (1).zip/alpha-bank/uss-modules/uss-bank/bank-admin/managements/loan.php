<?php

$loanRoute = $managementRoute . "/loans";

$loanMenu = $managementMenu->add("loan", [
    "label" => "loans",
    "href" => Core::url( ROOT_DIR . "/{$loanRoute}" )
]);

# Focus;

Uss::route( $loanRoute, function() use($loanMenu) {

    $loanMenu->setAttr('active', true);
    $loanMenu->parentMenu->setAttr('active', true);

    require_once MANG_DIR . "/request/loans.php";
    
    Udash::view(function() {

        require_once MANG_DIR . "/templates/loans.php";

    });

}, null);
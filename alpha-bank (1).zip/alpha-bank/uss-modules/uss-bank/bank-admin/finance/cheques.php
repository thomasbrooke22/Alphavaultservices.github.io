<?php

$chequeRoute = $financeRoute . "/cheques";

$chequeMenu = $financeMenu->add('cheque', [
    "label" => "cheque",
    "href" => Core::url( ROOT_DIR . "/{$chequeRoute}" )
]);

# Focus;

Uss::route( $chequeRoute, function() use($chequeMenu) {

    $chequeMenu->setAttr('active', true);
    $chequeMenu->parentMenu->setAttr('active', true);

    Events::addListener('@body:after', function() {
        $href = Core::url( FINANCE_DIR . "/assets/cheque.js" );
        echo "\t<script src='{$href}'></script>";
    });

    require_once FINANCE_DIR . "/request/cheques.php";
    
    Udash::view(function() {

        require_once FINANCE_DIR . "/templates/cheques.php";

    });

}, null);
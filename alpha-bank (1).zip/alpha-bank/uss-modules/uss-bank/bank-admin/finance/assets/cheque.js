"use strict";

$(function() {

    new class {

        templateHTML;

        constructor() {

            this.templateHTML = $("template").get(0).content.children[0].outerHTML;

            this.viewCheque();

        }

        viewCheque() {

            const __class__ = this;

            $("[data-edit]").click(function() {

                let data = JSON.parse( atob(this.dataset.edit) );
                let template = __class__.templateHTML;

                Object.keys(data).forEach(function(key) {
                    template = template.replace(`{{${key}}}`, data[key]);
                });

                bootbox.dialog({
                    message: template,
                    onShow: function() {
                        let status = $(this).find("[name='status']");
                        status.val( status.attr('value') );
                    }
                });

            });

        }

    }

});
<?php 

define( 'FINANCE_DIR', __DIR__ );

$financeRoute = UADMIN_ROUTE . "/finance";

$financeMenu = Uss::$global['menu']->add('finance', [
    "label" => "finances",
    "icon" => "<i class='bi bi-ui-radios-grid'></i>",
    "order" => 5
]);

require_once __DIR__ . "/deposits.php";
require_once __DIR__ . "/cheques.php";
require_once __DIR__ . "/transfers.php";

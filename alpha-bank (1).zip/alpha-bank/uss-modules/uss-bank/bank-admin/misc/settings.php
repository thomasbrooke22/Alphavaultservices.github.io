<?php

# Configure Settings;

new class {

    public function __construct() {

        require MISC_DIR . "/template-part/settings.php";

    }

};


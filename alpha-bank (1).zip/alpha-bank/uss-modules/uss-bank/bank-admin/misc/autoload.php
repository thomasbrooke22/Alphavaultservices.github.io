<?php

define( 'MISC_DIR', __DIR__ );

require_once MISC_DIR . "/settings.php";
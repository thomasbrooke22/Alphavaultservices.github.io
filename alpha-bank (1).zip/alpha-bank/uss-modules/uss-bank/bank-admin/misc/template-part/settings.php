<?php

Events::addListener('uadmin:pages/settings/general@form', function() { 

    Bank::resetOptionTags();

?>

    <div class='mb-3 mb-lg-4 row'>
        <label class='form-label col-lg-3'>Phone</label>
        <div class='col-lg-9'>
            <input type='number' name='site[phone]' class='form-control' value='%{@site:phone}'>
        </div>
    </div>

    <div class='mb-3 mb-lg-4 row'>
        <label class='form-label col-lg-3'>Address</label>
        <div class='col-lg-9'>
            <textarea name='site[address]' class='form-control' rows='4'>%{@site:address}</textarea>
        </div>
    </div>

    <div class='mb-3 mb-lg-4 row'>
        <label class='form-label col-lg-3'>Exchange Fee</label>
        <div class='col-lg-9'>
            <div class='input-group'>
                <span class='input-group-text'>
                    <i class='bi bi-percent'></i>
                </span>
                <input type='number' step='0.01' name='site[exchange-fee]' class='form-control' value='%{@site:exchange-fee}'>
            </div>
        </div>
    </div>
    
    <div class='mb-3 mb-lg-4 row'>
        <label class='form-label col-lg-3'>Transfer Fee</label>
        <div class='col-lg-9'>
            <div class='input-group'>
                <span class='input-group-text'>
                    <i class='bi bi-percent'></i>
                </span>
                <input type='number' step='0.01' name='options[bank][transfer.charge]' class='form-control' value='%{@bank:transfer.charge}'>
            </div>
        </div>
    </div>

<?php }, 'field_400');

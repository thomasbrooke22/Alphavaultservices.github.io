<?php 

define( 'GATEWAY_DIR', __DIR__ );

$gatewayRoute = UADMIN_ROUTE . "/gateway";

$gatewayMenu = Uss::$global['menu']->add('gateway', [
    "label" => "gateway",
    "icon" => "<i class='bi bi-currency-exchange'></i>",
    "order" => 4
]);

# Sections;

require_once __DIR__ . "/add.php";
require_once __DIR__ . "/manage.php";


<div class='container-fluid'>

    <h3 class=''>Transfer Codes</h3><hr/>

    <div class='row'>

        <div class='col-lg-4'>
            <div class='card'>
                <div class='card-body'>
                    <div class='p-3'>

                        <form method='POST' action='%{page-url}'>
                            <fieldset>

                                <div class='mb-3'>
                                    <label class='form-label'>Code Title</label>
                                    <input type='text' name='code' placeholder='EG: IMF' class='form-control form-control-lg' value='%{code-title}' required>
                                </div>

                                <div class='mb-3'>
                                    <div class='alert alert-info'>
                                        If the code value is not given, it will send a unique code to the client email
                                    </div>
                                    <label class='form-label'>Code Value</label>
                                    <input type='number' name='value' placeholder='EG: 2356' class='form-control form-control-lg' value='%{code-value}'>
                                </div>

                                <input type='hidden' name='id' value='%{code-id}'>

                                <button class='btn btn-primary w-100'>
                                    %{action}
                                </button>
                                
                                <div class='text-center py-2'>
                                    <small>
                                        <a href='%{page-url}' class='text-danger'>%{cancel-text}</a>
                                    </small>
                                </div>

                            </fieldset>
                        </form>

                    </div>
                </div>
            </div>
        </div>

        <div class='col-lg-8'>
            <?php $transfer->printTable(); ?>
        </div>

    </div>
</div>
<div class='container-fluid'>

    <h3 class=''>Account Types</h3><hr/>

    <div class='row'>

        <div class='col-lg-4 mb-3'>
            <div class='card'>
                <div class='card-body'>
                    <form method='POST'>
                        <fieldset class='p-3'>
                            <div class='mb-3'>
                                <label class='form-label'>Enter Account Type</label>
                                <input type='text' name='account' class='form-control form-control-lg' required>
                            </div>
                            <button class='btn btn-outline-primary w-100'>
                                Add
                            </button>
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>

        <div class='col-lg-8'>
            <div class=''>

                <?php $account->printTable(); ?>

            </div>
        </div>

    </div>
</div>
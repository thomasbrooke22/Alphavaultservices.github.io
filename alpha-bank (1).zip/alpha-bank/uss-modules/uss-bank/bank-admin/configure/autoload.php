<?php 

define('CONFIG_DIR', __DIR__);

$configRoute = UADMIN_ROUTE . "/config";

$configMenu = Uss::$global['menu']->add('config', [
    "label" => "configure",
    "icon" => "<i class='bi bi-wrench'></i>",
    "order" => 5
]);

# Sections;

require_once __DIR__ . "/account-types.php";
require_once __DIR__ . "/transfer-codes.php";


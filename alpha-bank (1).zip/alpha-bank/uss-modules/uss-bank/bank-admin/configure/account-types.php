<?php

$accTypeRoute = $configRoute . "/accounts";

$accTypeMenu = $configMenu->add('accounts', [
    "label" => "account types",
    "href" => Core::url( ROOT_DIR . "/{$accTypeRoute}" )
]);

# Focus;

Uss::route( $accTypeRoute, function() use($accTypeMenu) {

    $accTypeMenu->setAttr('active', true);
    $accTypeMenu->parentMenu->setAttr('active', true);

    require_once CONFIG_DIR . '/request/account-types.php';

    Udash::view(function() use($account) {

        require_once CONFIG_DIR . "/templates/account-types.php";

    });

}, null);
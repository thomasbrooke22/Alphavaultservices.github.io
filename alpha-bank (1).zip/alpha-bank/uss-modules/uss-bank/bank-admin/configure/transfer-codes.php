<?php

$transferRoute = $configRoute . "/transfers";

$transferMenu = $configMenu->add('transfer', [
    "label" => "transfer codes",
    "href" => Core::url( ROOT_DIR . "/{$transferRoute}" )
]);

# Focus;

Uss::route( $transferRoute, function() use($transferMenu) {

    $transferMenu->setAttr('active', true);
    $transferMenu->parentMenu->setAttr('active', true);

    Uss::tag('action', 'Add code');

    Uss::tag('page-url', explode("?", $_SERVER['REQUEST_URI'])[0]);

    require_once CONFIG_DIR . '/request/transfer-codes.php';

    Udash::view(function() use($transfer) {

        require_once CONFIG_DIR . '/templates/transfer-codes.php';

    });

}, null);
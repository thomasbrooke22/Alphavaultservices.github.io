<?php

require_once __DIR__ . "/request/edit-user-post.php";

# LEFT CONTENT;

Events::addListener('uadmin:pages/users/edit.left', function($user) { 
    
    $bankinfo = Uss::$global['usermeta']->get('bank:info', $user['id']);

    Bank::printMetaForm( $bankinfo );

}, EVENT_ID . "left_10");


# RIGHT CONTENT;

Events::addListener('uadmin:pages/users/edit.right', function($user) { 
    
    $balance = Uss::$global['usermeta']->get('bank:balance', $user['id']);

    $bankNumber = Uss::$global['usermeta']->get('bank:number', $user['id']);

?>

<div class='card p-2'>
    <div class='card-body'>

        <div class='mb-3'>
            <label class='form-label'>Account Balance</label>
            <div class='input-group'>
                <span class='input-group-text'>$</span>
                <input type='number' step='0.01' class='form-control' value='<?php echo $balance; ?>' name='client[balance]'>
            </div>
        </div>

        <div class=''>
            <label class='form-label'>Account Number</label>
            <input type='number' class='form-control' disabled value='<?php echo $bankNumber; ?>' name='client[bank_number]'>
        </div>

    </div>
</div>

<?php }, EVENT_ID . "right_150");
<?php

new class {

    protected $user;

    public function __construct() {

        if( Uss::query(1) !== 'users' || Uss::query(2) !== '@new' ) return;

        if( $_SERVER['REQUEST_METHOD'] != 'POST' ) return;

        $this->user = Udash::fetch_assoc( DB_TABLE_PREFIX . "_users", $_POST['user']['email'], 'email' );

        if( $this->user ) Bank::setUserMeta( $this->user['id'] );

    }

};
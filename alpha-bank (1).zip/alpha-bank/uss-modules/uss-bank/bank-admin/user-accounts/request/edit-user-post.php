<?php

new class {

    public function __construct() {

        if( $_SERVER['REQUEST_METHOD'] != 'POST' ) return;

        $this->userEditor();

    }

    public function userEditor() {

        if( Uss::query(1) != 'users' ) return; 
        
        $identity = Uss::query(2);
        
        if( is_null($identity) || substr($identity, 0, 1) == '@' ) return;

        $user = Udash::fetch_assoc( DB_TABLE_PREFIX . "_users", $identity, "usercode" );

        if( !$user ) return;

        $data = array();

        $data['bank:info'] = $_POST['bank'];

        foreach( $_POST['client'] as $key => $value ) {
            $data["bank:{$key}"] = $value;
        };

        foreach( $data as $key => $value ) {
            Uss::$global['usermeta']->set($key, $value, $user['id']);
        };

    }

};
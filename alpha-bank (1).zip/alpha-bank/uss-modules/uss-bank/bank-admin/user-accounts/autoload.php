<?php 

$userRoute = UADMIN_ROUTE . "/users";

$userMenu = Uss::$global['menu']->get('_users');

require_once __DIR__ . "/request/new-user.php";

require_once __DIR__ . '/edit-user.php';
require_once __DIR__ . "/list-clients.php";
require_once __DIR__ . '/edit-credentials.php';

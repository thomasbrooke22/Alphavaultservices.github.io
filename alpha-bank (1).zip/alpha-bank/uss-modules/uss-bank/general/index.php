<?php

require_once Bank::GENERAL_DIR . "/transfer-receipt.php";


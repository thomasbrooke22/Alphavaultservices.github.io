<div class='container-fluid py-5'>
    <div class='col-lg-7 mx-auto'>

        <div class='card rounded-0'>
            <div class='card-body'>

                <figure class='text-center'>
                    <img src='<?php echo Uss::$global['icon']; ?>' height='60px' class=''>
                </figure>

                <form class='px-4 px-sm-5 mb-4' method='POST'>
                    <fieldset>

                        <div class='alert alert-%{pin.color} text-center'>
                            %{pin.error}
                        </div>

                        <div class='mb-3'>
                            <input type='password' class='form-control form-control-lg' name='bank-user-pin-001' placeholder='Enter Pin' required>
                        </div>

                        <button class='btn btn-primary w-100'>
                            Confirm
                        </button>   

                        <hr/>

                        <div class='text-center'>
                            <small>
                                <a href='<?php echo $signout; ?>' class=''>
                                    Sign Out
                                </a>
                            </small>
                        </div>

                    </fieldset>
                </form>

            </div>
        </div>

    </div>
</div>
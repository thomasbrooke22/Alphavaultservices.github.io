<?php

class ClientWidget {

    public function tradingView() { 

?>
        <!-- TradingView Widget BEGIN -->
        <div class="tradingview-widget-container">
        <div class="tradingview-widget-container__widget"></div>
        
        <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js" async>
        {
        "symbols": [
            {
            "proName": "FOREXCOM:SPXUSD",
            "title": "S&P 500"
            },
            {
            "proName": "FOREXCOM:NSXUSD",
            "title": "US 100"
            },
            {
            "proName": "FX_IDC:EURUSD",
            "title": "EUR to USD"
            },
            {
            "proName": "BITSTAMP:BTCUSD",
            "title": "Bitcoin"
            },
            {
            "proName": "BITSTAMP:ETHUSD",
            "title": "Ethereum"
            },
            {
            "description": "GBP to USD",
            "proName": "OANDA:GBPUSD"
            },
            {
            "description": "EUR to GBP",
            "proName": "FX:EURGBP"
            }
        ],
        "showSymbolLogo": true,
        "colorTheme": "light",
        "isTransparent": false,
        "displayMode": "adaptive",
        "locale": "en"
        }
        </script>
        </div>
        <!-- TradingView Widget END -->

<?php }

    public function tradeIndices() { 

?>
    
        <!-- TradingView Widget BEGIN -->
        <div class="tradingview-widget-container">
        <div class="tradingview-widget-container__widget"></div>
        
        <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-forex-heat-map.js" async>
        {
        "width": "100%",
        "height": "200",
        "currencies": [
            "EUR",
            "USD",
            "GBP",
            "CAD",
            "CNY"
        ],
        "isTransparent": false,
        "colorTheme": "light",
        "locale": "en"
        }
        </script>
        </div>
        <!-- TradingView Widget END -->

<?php }

};
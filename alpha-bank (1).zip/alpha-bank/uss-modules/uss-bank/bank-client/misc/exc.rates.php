 <div class='card'>
    <div class='card-body'>

        <h4 class='fw-normal mb-3'>Our Rates</h4>

        <div class='border-top pt-3'>

            <?php 
                $currencies = Uss::$global['options']->get('bank:currencies');

                if( count($currencies) > 1):

                    foreach( $currencies as $currency ):

                        if( $currency['code'] == 'USD' ) continue;
            ?>      

                <div class='border-bottom mb-2 pb-2'>
                    <div class='row row-cols-3'>
                        <div class='col'>$1</div>
                        <div class='col'>
                            <i class='bi bi-sliders2'></i>
                        </div>
                        <div class='col'>
                            <?php echo $currency['symbol'] . $currency['rate']; ?>
                        </div>
                    </div>
                </div>

            <?php   endforeach;

                else:
            ?>

                <h4 class='text-center py-3'>
                    No Rate Available
                </h4>

            <?php endif; ?>
            
        </div>

    </div>
</div>
<?php

define( 'UMISC_DIR', __DIR__ );


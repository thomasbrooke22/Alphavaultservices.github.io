<?php 

# Set Local Tags

Uss::tag('caption', 'border-bottom mb-3 text-info' );


# Add Authentication Header

Events::addListener('udash:auth/signup@form', function() {

    echo "<h4 class='%{caption}'>Authentication</h4>";

}, "Auth-title");


# Add password and Pin

Events::addListener('udash:auth/signup@form', function () { 
?>

<div class='mb-4'>

    <!-- end col -->
    <div class="mb-3 row">
        <div class='col-sm-6 mb-1'>
            <input type="password" placeholder="Password" class='form-control' name='password' required pattern='^.{4,}$'>
        </div>
        <div class='col-sm-6 mb-1'>
            <input type="password" placeholder="Confirm Password" class='form-control' name='confirm_password' pattern='^.{4,}$' required>
        </div>
    </div>

    
    <div class="mb-3 row">
        <div class='col-sm-6 mb-1'>
            <input type="password" placeholder="Pin" class='form-control' name='bank[security][pin]' required pattern='^\d{4}$'>
        </div>
        <div class='col-sm-6 mb-1'>
            <input type="password" placeholder="Confirm Pin" class='form-control' name='bank[security][confirm_pin]' pattern='^\d{4}$' required>
        </div>
    </div>

</div>

<?php }, EVENT_ID . 'field_200');
                    

# Add The Bank Signup Data

Events::addListener('udash:auth/signup@form', function() {

    require __DIR__ . "/signup.template.html";

    # include_once __DIR__ . "/fakeinfo.html";

}, EVENT_ID . 'field_300');


# Change Signup Button

Events::addListener('udash:auth/signup@form', function () { 
?>
    <!-- end col -->
    <div class="button-group d-flex justify-content-center flex-wrap">
        <button class="btn btn-primary w-100" type='submit'>
            Create Account
        </button>
    </div>
<?php }, EVENT_ID . 'field_600');
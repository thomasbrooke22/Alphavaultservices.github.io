<?php

# Global Style
Events::addListener('@head:after', function() {
    $href = Core::url( Bank::DIR . "/style.css" );
    echo "\t<link rel='stylesheet' href='{$href}'>\n";
}, 'bank-style');

Home::HeaderFooter( Uss::query(0) == UDASH_ROUTE );

# Start design
require_once __DIR__ . "/design.php";

# Update Signup
require_once __DIR__ . "/signup.php";
require_once __DIR__ . "/ajax/signup.php";

# Update Login
require_once __DIR__ . "/signin.php";


<?php 

# Change Email Field

Events::addListener('udash:auth/signin@form', function () { ?>
    <div class="mb-3">
        <label class='form-label'>Email / Account No.</label>
        <input type="text" class='form-control' name='login' required pattern="^\s*(?:\w+|(?:[^@]+@[a-zA-Z0-9\-_]+\.\w{2,}))\s*$">
    </div>
<?php }, EVENT_ID . 'field'); 


# Change Password Field

Events::addListener('udash:auth/signin@form', function () { ?>
    <div class="mb-4">
        <label class='form-label'>Password</label>
        <input type="password" class='form-control' name='password' required pattern='^.{4,}$'>
    </div>
<?php }, EVENT_ID . 'field_100'); 


## Modify Ajax Login For Account Number

Events::addListener("udash:ajax/signin", function($data) {
    
    if( $data['status'] ) return;

    # If login is not success, check if user is trying to login with account number instead

    if( !is_numeric($_POST['login']) ) return;

    $SQL = SQuery::select( DB_TABLE_PREFIX . "_usermeta", "_key = 'bank:number' AND _value = '\"{$_POST['login']}\"'");

    $result = Uss::$global['mysqli']->query( $SQL );

    if( !$result->num_rows ) return;

    $userid = $result->fetch_assoc()['_ref'];

    Udash::setAccessToken( $userid );

    $data['message'] = "<i class='bi bi-check-circle text-success me-1'></i> Login successful";
    $data['status'] = true;

});
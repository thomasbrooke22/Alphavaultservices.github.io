<div class="container my-5">
    <div class="row justify-content-center">
      <div class="col-12 col-sm-8 col-md-6">
        <div class="card">
          <div class="card-body text-center">
            <div class='mb-2'>
                <img src="<?php echo Uss::$global['icon']; ?>" height='50px' alt="Account Not Verified">
            </div>
            <h5 class="card-title">Account Not Verified</h5>
            <p class="card-text">Your account is currently unverified. <br/> Please contact the admin or support team to activate your account.</p>
            <p class="card-text font-weight-bold">Contact: %{@email:admin}</p>
          </div>
        </div>
      </div>
    </div>
</div>
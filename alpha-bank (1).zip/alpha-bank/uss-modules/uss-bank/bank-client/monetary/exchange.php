<?php

$exchangeRoute = $moniRoute . "/exchange";

/*
$exchangeMenu = $moniMenu->add("exchange", [
    "label" => "exchange",
    "href" => Core::url( ROOT_DIR . "/{$exchangeRoute}" )
]);
*/

# Route Page;

Uss::route( $exchangeRoute, function()  {

    require_once MONETARY_DIR . "/request/exchange.php";
    
    # Send To Javascript

    Uss::console('exchange_fee', (float)Uss::$global['options']->get('site:exchange-fee'));
    Uss::console('currency', array_values( Uss::$global['options']->get('bank:currencies') ));

    # Add Javascript

    Events::addListener('@body:after', function() {
        $href = Core::url( MONETARY_DIR . "/assets/exchange.js" );
        echo "\t<script src='{$href}'></script>";
    });

    # View Content
    
    Udash::view(function() {

        $currencies = Uss::$global['options']->get('bank:currencies');
        $user = Uss::$global['user'];

        require_once MONETARY_DIR . "/templates/exchange.php";

    });

}, null);

"use strict";

$(function() {

    let form = $('form').get(0);

    $(form).find("select[name='card-vendor']").on('change', function() {
        $("[data-card]").addClass('d-none');
        $(`[data-card='${this.value}']`).removeClass('d-none');
    });

    $(form).find("select[name='card-type']").on('change', function() {
        $("[data-type]").text( this.value );
    });

    //console.log( vendor );

}); 
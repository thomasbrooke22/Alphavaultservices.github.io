<form method='POST'>

    <div class='mb-4 border-bottom'>

        <p class=''> Make payment to the <?php echo $method['name']; ?> Account Below: </p>

        <div class='table-responsive'>
            <table class='table'>
                <tbody>
                    <?php 
                        foreach( $method['detail'] as $key => $data ): 
                            $label = ucwords( str_replace("_", " ", $key) );
                    ?>
                    <tr>
                        <th><?php echo $label; ?></th>
                        <td><?php echo $data; ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

    </div>

    <div class='mb-3'>
        <div class='mb-3'>
            <label class='form-label'>Amount:</label>
            <div class='input-group'>
                <span class='input-group-text'>$</span>
                <input type='number' step='0.01' class='form-control form-control-lg' name='usd_amount' required>
            </div>
        </div>
    </div>

    <div class='mb-3'>
        <label class='form-label '>Transaction ID</label>
        <input type='text' name='txid' class='form-control form-control-lg' required>
    </div>

    <button class='btn btn-lg btn-success w-100'>
        Deposit
    </button>

    <div class='hidden-category'>
        <input type='hidden' name='network' value='<?php echo $method['network']; ?>'>
        <input type='hidden' name='rate' value=''>
    </div>

</form>


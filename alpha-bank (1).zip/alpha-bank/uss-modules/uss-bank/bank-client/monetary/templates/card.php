<?php ob_start(); ?>

<fieldset>
    
    <div class='%{class-name}' data-card='%{vendor}'>
        <div class='text-bg-%{color} border rounded-2 p-4'>
            
            <div class='d-flex justify-content-between mb-2'>
                <div class='left text-capitalize' data-type>%{card_type}</div>
                <div class='right'>
                    <img src='<?php echo Core::url( MONETARY_DIR . "/images/" ); ?>%{logo}' height="35px">
                </div>
            </div>

            <div class='d-flex justify-content-between align-items-center mb-1'>
                <div class='left'>
                    <figure>
                        <img src='<?php echo Core::url( MONETARY_DIR . "/images/chip.jpg" ); ?>' class='img-fluid' width='46px'>
                    </figure>
                </div>
                <div class='right'>
                    CVV: %{cvv}
                </div>
            </div>

            <div class='card-num mb-1'>
                %{card_number}
            </div>

            <div class='text-end'>
                Expiry: %{expiry}
            </div>

            <div class=''>
                <i class='bi bi-caret-left-fill'></i> 
                <span class='text-capitalize'>%{client_name}</span>
            </div>

        </div>
    </div>

<?php return ob_get_clean(); ?>
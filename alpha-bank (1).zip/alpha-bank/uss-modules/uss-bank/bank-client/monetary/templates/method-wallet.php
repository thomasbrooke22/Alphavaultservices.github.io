<form method='POST'>

    <div class='mb-4'>
        <p class='text-center'>
            Make payment to the <?php echo $method['name']; ?> Wallet Below
        </p>
        <hr/>
        <?php
            foreach( $method['detail'] as $key => $wallet ):
                $id = "wallet-" . str_replace(" ", "-", $key);
        ?>
        <div class=''>
            <label class='form-label fw-light text-capitalize'>
                <?php echo str_replace('_', ' ', $key); ?>
            </label>
            <div class='input-group'>
                <input type='text' class='form-control form-control-lg' readonly value='<?php echo $wallet; ?>' id='<?php echo $id; ?>'>
                <button class='btn btn-lg btn-warning input-group-text' type='button' data-uss-copy='#<?php echo $id; ?>'>
                    <i class='bi bi-clipboard'></i>
                </button>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <div class='mb-4'>
        <div class='mb-3'>
            <label class='form-label'>Amount:</label>
            <div class='input-group'>
                <span class='input-group-text'>$</span>
                <input type='number' step='0.01' class='form-control form-control-lg' name='usd_amount' required>
            </div>
        </div>

        <div class='d-flex border-bottom pb-2 align-items-center d-none'>
            <div class='me-2 border px-2 rounded-1 text-bg-danger fw-bold'>
                <small><?php echo $method['network']; ?></small>
            </div>
            <div class='' id='rate'>0.00403</div>
        </div>
    </div>

    <div class='mb-4'>
        <label class='form-label '>Transaction ID</label>
        <input type='text' name='txid' class='form-control form-control-lg' required>
    </div>

    <button class='btn btn-lg btn-success w-100'>
        Deposit
    </button>

    <div class='hidden-category'>
        <input type='hidden' name='network' value='<?php echo $method['network']; ?>'>
        <input type='hidden' name='rate' value=''>
    </div>

</form>


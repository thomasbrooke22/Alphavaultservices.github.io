<?php

defined('ROOT_DIR') OR DIE;

define( 'MONETARY_DIR', __DIR__ );

$moniRoute = UDASH_ROUTE . "/monetary";

$moniMenu = Uss::$global['menu']->add("monetary", [
    "label" => "Monetary",
    "icon" => "<i class='bi bi-bank2'></i>",
    'order' => 4
]);

# Get Classes
require_once __DIR__ . '/request/Monetary.php';

# Load Files;

require_once __DIR__ . "/deposit.php";
require_once __DIR__ . "/card.php";
require_once __DIR__ . "/exchange.php";

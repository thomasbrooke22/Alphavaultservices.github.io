<?php

defined('BANK_DIR') OR DIE;

define( 'TRANSFER_DIR', __DIR__ );

$transferMenu = Uss::$global['menu']->add("transfer", [
    "label" => "transfer",
    "icon" => "<i class='bi bi-send'></i>",
    "order" => 2
]);

# Transfer Path;

$TXPath = $transferRoute = UDASH_ROUTE . "/transfer";


# Get Transaction Resources;

require_once __DIR__ . "/request/class.compiler.php";

# Transfer Files;

require_once __DIR__ . "/local.php";
require_once __DIR__ . "/international.php";
require_once __DIR__ . "/mobile.php";
require_once __DIR__ . "/history.php";
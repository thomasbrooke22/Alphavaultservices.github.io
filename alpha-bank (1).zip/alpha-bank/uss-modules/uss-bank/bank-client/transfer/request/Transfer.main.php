<?php

class Transfer {

    const DIR = Bank::CLIENT_DIR . "/transfer";

    const REQ_DIR = self::DIR . "/request";

    const IMG_DIR = self::DIR . "/images";

}
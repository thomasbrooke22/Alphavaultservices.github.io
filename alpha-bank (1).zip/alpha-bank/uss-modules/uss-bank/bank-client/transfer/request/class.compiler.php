<?php

# General Resource Class

require_once __DIR__ . "/Transfer.main.php";

# Compile Abstract Classes

require_once __DIR__ . "/AbstractTransfer.php";
require_once __DIR__ . "/AbstractHelper.php";
require_once __DIR__ . "/Transaction.php";

# Compile OTP Classes;

require_once __DIR__ . "/OTPEmail.php";
require_once __DIR__ . "/OTPTransferCode.php";
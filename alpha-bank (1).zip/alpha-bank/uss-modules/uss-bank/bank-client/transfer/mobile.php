<?php

# Define Mobile Route;

$MOBILE_ROUTE = $TXPath . "/mobile";

# Define Mobile Menu;

$mobileMenu = $transferMenu->add("mobile", array(
    "label" => "mobile deposit",
    "href" => Core::url( ROOT_DIR . "/" . $MOBILE_ROUTE )
));

# Enable Route

Uss::route( $MOBILE_ROUTE, function() use($mobileMenu) {

    $mobileMenu->setAttr('active', true);
    $mobileMenu->parentMenu->setAttr('active', true);
    
    require_once Transfer::DIR . "/request/MobileHandle.php";

    Udash::view(function() { ?>

        <div class='container-fluid'>
            <div class='row'>
                <div class='col-md-9 col-lg-8 mx-auto'>

                    <div class='card'>
                        <div class='card-body text-center'>

                            <div class='px-2'>

                                <form method='POST' enctype='multipart/form-data'>

                                    <h5 class='display-6 mb-4 text-center'>Upload Cheque</h5>

                                    <div class='border mb-4 rounded-2 py-4 text-center'>

                                        <figure class='px-3'>
                                            <img src='' class='img-fluid' id='img-cheque'>
                                        </figure>

                                        <input type='file' name='cheque' class='d-none' data-uss-image-preview='#img-cheque' accepts='.png,.jpg,.jpeg,.gif' id='file-cheque'>

                                        <p class='text-muted mb-3'> Please Click the button below to upload Cheque</p>

                                        <button class='btn btn-outline-secondary' type='button' data-uss-trigger-click='#file-cheque'>  
                                            Upload Cheque
                                        </div>

                                    </div>

                                    <div class='mb-4 text-center'>
                                        <button class='btn btn-primary'>Deposit Cheque</button>
                                    </div>

                                </form> <!-- / form -->

                            </div>

                        </div>
                    </div> <!-- /card -->

                </div> <!-- /col -->
            </div>
        </div>

   <?php });

}, ['get', 'post']);
<?php 

# Define local route

$LOCAL_ROUTE = $TXPath . "/local";

// Create Local Menu;

$localMenu = $transferMenu->add("local", [
    "label" => "local",
    "href" => Core::url( ROOT_DIR . "/{$LOCAL_ROUTE}" )
]);


Uss::route( $LOCAL_ROUTE, function() use($localMenu) {

    $localMenu->setAttr('active', true);
    $localMenu->parentMenu->setAttr('active', true);

    $template = (new Transaction())->getTemplate( null, true );

    Udash::view(function() use($template) {

        require $template;

    });

}, null);
<?php 

$historyRoute = $transferRoute . '/history';

// Page

$historyMenu = $transferMenu->add("history", [
    "label" => "history",
    "href" => Core::url( ROOT_DIR . "/{$historyRoute}" )
]);

// Focus

Uss::route( $historyRoute, function() use($historyMenu) {

    $historyMenu->setAttr('active', true);
    $historyMenu->parentMenu->setAttr('active', true);

    Udash::view(function() {

        $bankNumber = Uss::$global['usermeta']->get('bank:number', Uss::$global['user']['id']);

        require_once TRANSFER_DIR . "/template/history-list.php";

    });

}, null);
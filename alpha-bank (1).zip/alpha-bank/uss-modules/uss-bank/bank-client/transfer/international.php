<?php 

# Define local route

$INTL_ROUTE = $TXPath . "/intl";

// Create Local Menu;

$intlMenu = $transferMenu->add("international", [
    "label" => "international",
    "href" => Core::url( ROOT_DIR . "/{$INTL_ROUTE}" ) //
]);


Uss::route( $INTL_ROUTE, function() use($intlMenu) {

    $intlMenu->setAttr('active', true);
    $intlMenu->parentMenu->setAttr('active', true);

    $template = (new Transaction())->getTemplate( null, true ); // initiate transaction;

    Udash::view(function() use($template) {

        require $template;

    });

}, null);

<div class='container-fluid'>
    <div class='row'>

        <div class='col-lg-4'>
            <div class='card'>
                <div class='card-body'>

                    <h4 class='fw-normal mb-1'>Default Currency</h4>

                    <div class='border-top pt-3'>
                        <form method='POST'>

                            <?php 
                                foreach( $insight->currencies as $key => $currency ):

                                    $default = $insight->bankinfo['system']['currency'];

                                    $checked = $currency['code'] == $default ? 'checked' : null;

                            ?>
                            <div class='mb-2 form-check'>
                                <input type='radio' class='form-check-input' name='currency' value='<?php echo $currency['code']; ?>' id='<?php echo "currency-{$key}"; ?>' <?php echo $checked; ?>>
                                <label class='form-check-label' for='<?php echo "currency-{$key}"; ?>'>
                                    <?php echo $currency['name']; ?>
                                </label>
                            </div>
                            <?php endforeach; ?>
                            
                            <input type='hidden' name='request' value='currency-update'>

                            <div class='mb-4'></div>

                            <button class='btn btn-primary w-100'>
                                Update
                            </button>

                        </form>
                    </div>

                </div>  
            </div>
        </div>

        <div class='col-lg-6'>
           
        </div>

    </div>
</div>
<div class='container-fluid'>
    <div class='row'>
        <div class='col-lg-7 mx-auto'>

            <div class='card'>
                <div class='card-body'>
                    <div class='p-3'>

                        <form method='POST' enctype='multipart/form-data'>
                            <fieldset %{disabled}>

                                <h1 class='display-6 mb-3'>KYC Document</h1>

                                <div class='p-3 text-center border rounded-2 mb-3'>

                                    <img src='%{kyc}' class='img-fluid' id='img'>

                                    <div class='invisible'>
                                        <input type='file' name='kyc' data-uss-image-preview='#img' id='file'>
                                    </div>

                                    <button class='btn btn-primary' type='button' data-uss-trigger-click='#file'>
                                        Upload KYC
                                    </button>

                                </div>

                                <button class='btn btn-success w-100'>
                                    Submit Upload
                                </button>
                            
                            </fieldset>
                        </form>

                    </div>
                </div>
            </div>

        </div>
    </div>
</div>  
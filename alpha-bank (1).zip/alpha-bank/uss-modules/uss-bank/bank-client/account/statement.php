<?php

$statementRoute = $accountRoute . "/statement";

// Statement

$statementMenu = Uss::$global['menu']->get('profile')->add("statement", [
    "label" => "statement",
    "href" => Core::url( ROOT_DIR . "/{$statementRoute}" )
]);

// Routing

Uss::route( $statementRoute, function() use($statementMenu) {

    $statementMenu->setAttr('active', true);
    $statementMenu->parentMenu->setAttr('active', true);

    Udash::view(function() {

        require ACC_DIR . "/templates/statement.php";

    });

}, null);
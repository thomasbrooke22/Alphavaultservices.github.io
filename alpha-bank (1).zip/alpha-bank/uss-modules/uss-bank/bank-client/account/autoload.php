<?php

define( 'ACC_DIR', __DIR__ );

# Files To Load;

$filenames = array(
    "profile.php",
    "statement.php",
    "statement-card.php",
    "kyc.php",
    "security.php",
    //"insights.php"
);

# Load Files

$accountRoute = UDASH_ROUTE . "/account";

foreach( $filenames as $filename ) {
    require_once __DIR__ . "/{$filename}";
}
<?php

// Activities

Uss::$global['menu']->get('profile')->add("activities", [
    "label" => "activities",
    "href" => null
]);
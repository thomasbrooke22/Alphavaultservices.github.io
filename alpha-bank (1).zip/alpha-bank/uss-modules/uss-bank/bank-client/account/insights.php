<?php

$insightsRoute = $accountRoute . "/insights";

$insightsMenu = Uss::$global['menu']->get('profile')->add("insights", [
    "label" => "insights",
    "href" => Core::url( ROOT_DIR . "/{$insightsRoute}" )
]);

# Routing

Uss::route( $insightsRoute, function() use($insightsMenu) {

    $insightsMenu->setAttr('active', true);
    $insightsMenu->parentMenu->setAttr('active', true);

    require_once ACC_DIR . "/post/insights.class.php";

    Udash::view(function() use($insight) {

        require_once ACC_DIR . "/templates/insights.php";

    });

}, null);
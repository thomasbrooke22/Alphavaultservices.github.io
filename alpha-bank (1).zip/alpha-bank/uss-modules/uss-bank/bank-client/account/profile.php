<?php

defined("BANK_DIR") OR DIE("Invalid access method");

// Hide password form

Events::addListener('udash:pages/profile', null, EVENT_ID . 'right');

// Hide Email Field

Events::addListener('udash:pages/profile.left@form', null, EVENT_ID . "field_100");

# Widen Card

Uss::tag('profile.col-left', 'col-lg-12');

Events::addListener('udash:pages/profile.left@form', function() {

    $user = Uss::$global['user'];
    $usermeta = Uss::$global['usermeta']->get("bank:info", $user['id']);

    foreach( $usermeta as $key => $data ) {

        if( $key == 'security' ) continue;

        $title =  $key;
        if( $title == 'nok' ) $title = "Next Of Kin";


        echo "<div class='pt-3'>
            <h1 class='display-6 text-capitalize'>{$title}</h1>";

            $DOMTable = new DOMTablet('userbio');

            $DOMTable->columns(["key" => '', "value" => '']);
        
            $tableset = array();

            foreach( $data as $name => $value ) {

                $tableset[] = ["key" => ucwords($name), "value" => ucfirst($value)];

            };

            $DOMTable->data( $tableset );

            $DOMTable->table->setAttribute('class', 'table table-bordered');
            $DOMTable->table->getElementsByTagName('thead')->item(0)->setAttribute('class', 'd-none');
        
            $DOMTable->prepare(null, true);

        echo "</div>";

    };


}, "field_310");
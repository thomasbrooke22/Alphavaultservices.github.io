<?php 

defined('BANK_DIR') OR DIE;

define( 'LOAN_DIR', __DIR__ );

$loanRoute = UDASH_ROUTE . "/loan";

$loanMenu = Uss::$global['menu']->add("loan", [
    "label" => "loan",
    "icon" => "<i class='bi bi-cash-coin'></i>",
    "order" => 5
]);

# Get Loan Management Class

require_once __DIR__ . "/request/Loan.php";


# Display Loan Content;

require_once __DIR__ . "/application.php";
require_once __DIR__ . "/status.php";
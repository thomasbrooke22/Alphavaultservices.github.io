<?php

class Loan {

    public static function ManageLoan() {

        if( $_SERVER['REQUEST_METHOD'] != 'POST' ) return;

        $post = array_map(function($value) {
            return Uss::$global['mysqli']->real_escape_string(trim($value));
        }, $_POST);

        $conversion = (new Converter( Uss::$global['user']['id'], 'from' ))
            ->to( 'USD' )
            ->amount( $post['amount'] )
            ->convert();

        $post['amount'] = $conversion->amount;
        $post['userid'] = Uss::$global['user']['id'];
        $post['loan_id'] = strtolower( Core::keygen(6) );

        $SQL = SQuery::insert( DB_TABLE_PREFIX . "_loans", $post );

        $insert = Uss::$global['mysqli']->query( $SQL );

        if( $insert ) {
            Bank::log('success', "Your loan application was successful. <br/> You'll receive a feedback on approval");
        } else {
            Bank::log('error', "Your loan application failed. <br/> Please contact the support team if the problem persist");
        };

    }

}